import type { JSX } from 'react';
export type DocsAttachment = {
    title: string;
    href: string;
    type?: string;
    size?: number;
};
export type DocsLeaf = {
    title: string;
    href: string;
    description?: string;
    updatedAt?: string;
    attachments?: DocsAttachment[];
};
export type DocsGroup = {
    title: string;
    id?: string;
    leaves: DocsLeaf[];
};
export type DocsSection = {
    title: string;
    id?: string;
    groups: DocsGroup[];
};
export type DocsTreeActionName = 'create-leaf' | 'rename-leaf' | 'duplicate-leaf' | 'delete-leaf' | 'move-leaf' | 'move-leaf-up' | 'move-leaf-down' | 'manage-attachments' | 'download-leaf' | 'rename-group' | 'delete-group' | 'move-group-up' | 'move-group-down' | 'rename-section' | 'delete-section' | 'download-section';
export type DocsTreeAction = {
    name: DocsTreeActionName;
    section: DocsSection;
    group?: DocsGroup;
    leaf?: DocsLeaf;
};
/** Host actions own mutations and authorization. The package renders controls only for allowed actions. */
export type DocsTreeActions = {
    available: (action: DocsTreeAction) => boolean;
    perform: (action: DocsTreeAction) => void | Promise<void>;
};
/** Remote persistence is host-owned. Local repository pages omit this provider. */
export type DocsRemoteProvider = {
    loadDraft: (slug: string) => Promise<{
        markdown: string;
        revision: number;
    }>;
    saveDraft: (slug: string, markdown: string, expectedRevision: number) => Promise<number>;
    publish: (slug: string, expectedRevision: number) => Promise<number>;
    history: (slug: string) => Promise<unknown[]>;
    uploadAttachment?: (slug: string, file: File) => Promise<DocsAttachment>;
};
export type DocsCapabilities = {
    edit?: boolean;
    save?: boolean;
    history?: boolean;
    publish?: boolean;
};
export type DocsMode = 'view' | 'attachments' | 'edit';
export declare function DocsWorkspaceNavigation({ sections, currentPath, actions, }: {
    sections: DocsSection[];
    currentPath: string;
    actions?: DocsTreeActions | undefined;
}): JSX.Element;
export declare function DocsWorkspaceToolbar({ capabilities, onEdit, onSave, onHistory, onPublish, remoteProvider, onModeChange, }: {
    attachments?: DocsAttachment[];
    capabilities?: DocsCapabilities | undefined;
    onEdit?: (() => void) | undefined;
    onSave?: (() => void) | undefined;
    onHistory?: (() => void) | undefined;
    onPublish?: (() => void) | undefined;
    remoteProvider?: DocsRemoteProvider | undefined;
    onModeChange?: ((mode: DocsMode) => void) | undefined;
}): JSX.Element;
export declare function DocsAttachmentsView({ attachments, onUpload, }: {
    attachments?: DocsAttachment[];
    onUpload?: ((file: File) => void | Promise<void>) | undefined;
}): JSX.Element;
//# sourceMappingURL=workspace.d.ts.map