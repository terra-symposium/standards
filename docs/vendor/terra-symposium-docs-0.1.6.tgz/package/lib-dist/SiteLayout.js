import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { colors } from '@terra-symposium/styling';
import { DocsToolbarFrame } from '@terra-symposium/styling/ui';
import { DocsWorkspaceNavigation, DocsWorkspaceToolbar, DocsAttachmentsView } from './workspace.js';
/** Shared Terra Docs page shell for independent installations and repository guides. */
export function DocsSiteLayout({ title, homeHref = '/', description, pageTitle, nodes, currentPath, hue = 145, children, sidebarContent, sections, attachments = [], capabilities, onEdit, onSave, onHistory, onPublish, remoteProvider, onModeChange, onUpload, treeActions, }) {
    const [accent, neutral] = colors(hue);
    const style = {
        '--terra-docs-accent': `rgb(${accent.light[8]})`,
        ...Object.fromEntries(accent.light.map((value, index) => [`--primary-${index + 1}`, value])),
        ...Object.fromEntries(neutral.light.map((value, index) => [`--secondary-${index + 1}`, value])),
    };
    const workspaceSections = sections ??
        nodes.map((node) => ({
            title: node.title,
            groups: [
                {
                    title: node.title,
                    leaves: (node.children?.length ? node.children : [node])
                        .filter((entry) => entry.href)
                        .map((entry) => ({ title: entry.title, href: entry.href })),
                },
            ],
        }));
    const activeLeaf = workspaceSections
        .flatMap((section) => section.groups.flatMap((group) => group.leaves))
        .find((leaf) => leaf.href === currentPath);
    return (_jsx("div", { className: "terra-docs-site", style: style, children: _jsxs("div", { className: "terra-docs-site-layout", children: [_jsxs("aside", { className: "terra-docs-site-sidebar", children: [_jsxs("header", { className: "terra-docs-site-header", children: [_jsx("a", { className: "terra-docs-site-brand", href: homeHref, children: title }), description && _jsx("span", { className: "terra-docs-site-description", children: description })] }), _jsx(DocsWorkspaceNavigation, { sections: workspaceSections, currentPath: currentPath, actions: treeActions }), sidebarContent] }), _jsxs("main", { className: "terra-docs-site-main", children: [_jsxs("header", { className: "terra-docs-document-header", children: [_jsx("h1", { children: pageTitle ?? activeLeaf?.title ?? title }), activeLeaf?.description && (_jsx("p", { className: "terra-docs-site-metadata", children: activeLeaf.description })), activeLeaf?.updatedAt && (_jsxs("p", { className: "terra-docs-site-metadata", children: ["Updated ", activeLeaf.updatedAt] }))] }), _jsxs(DocsToolbarFrame, { children: [_jsx(DocsWorkspaceToolbar, { attachments: attachments, capabilities: capabilities, onEdit: onEdit, onSave: onSave, onHistory: onHistory, onPublish: onPublish, remoteProvider: remoteProvider, onModeChange: onModeChange }), _jsx("div", { className: "terra-docs-formatting-slot" })] }), _jsx(DocsAttachmentsView, { attachments: attachments, onUpload: onUpload }), _jsx("article", { className: "terra-docs-site-article", children: children })] })] }) }));
}
//# sourceMappingURL=SiteLayout.js.map