import { marked } from 'marked';
import { enabledDocsBlocks } from './blocks.js';
const key = () => crypto.randomUUID();
function span(text, marks = []) {
    return { _type: 'span', _key: key(), text, marks };
}
function inline(tokens, markDefs) {
    if (!tokens)
        return [];
    return tokens.flatMap((token) => {
        if (token.type === 'strong')
            return inline(token.tokens, markDefs).map((item) => item._type === 'span' ? { ...item, marks: [...item.marks, 'strong'] } : item);
        if (token.type === 'em')
            return inline(token.tokens, markDefs).map((item) => item._type === 'span' ? { ...item, marks: [...item.marks, 'em'] } : item);
        if (token.type === 'del')
            return inline(token.tokens, markDefs).map((item) => item._type === 'span' ? { ...item, marks: [...item.marks, 'strike-through'] } : item);
        if (token.type === 'link') {
            const href = typeof token.href === 'string' ? token.href : '';
            if (!href || !/^(?:https?:\/\/|mailto:|\/|\.\.?\/|#)/i.test(href))
                return [span(token.raw)];
            const mark = key();
            markDefs.push({ _type: 'link', _key: mark, href });
            return inline(token.tokens, markDefs).map((item) => item._type === 'span' ? { ...item, marks: [...item.marks, mark] } : item);
        }
        if (token.type === 'text' || token.type === 'escape') {
            const pieces = (token.text ?? token.raw).split(/(\$[^$\n]+\$)/g).filter(Boolean);
            return pieces.map((piece) => /^\$[^$\n]+\$$/.test(piece)
                ? { _type: 'math', _key: key(), code: piece.slice(1, -1), inline: true }
                : span(piece));
        }
        if (token.type === 'codespan')
            return [span(token.text ?? token.raw, ['code'])];
        return [span(token.raw)];
    });
}
function textBlock(style, tokens, fallback) {
    const markDefs = [];
    const children = inline(tokens, markDefs);
    return {
        _type: 'block',
        _key: key(),
        style,
        markDefs,
        children: children.length ? children : [span(fallback)],
    };
}
/** Decode Markdown without dropping unsupported syntax; opaque tokens become raw blocks. */
export function markdownToDocsValue(markdown, options = {}) {
    const blocks = [];
    const richSource = markdown.replace(/^:::terra-docs ([A-Za-z]+)\s*\n([\s\S]*?)^:::\s*$/gm, (source, type, json) => {
        try {
            const data = JSON.parse(json);
            if (data._type === type && enabledDocsBlocks(options).includes(type)) {
                const placeholder = `TERRADOCSBLOCK${blocks.length}PLACEHOLDER`;
                blocks.push({ ...data, _key: data._key ?? key() });
                return `\n\n${placeholder}\n\n`;
            }
        }
        catch {
            /* Preserve malformed source. */
        }
        const placeholder = `TERRADOCSBLOCK${blocks.length}PLACEHOLDER`;
        blocks.push({ _type: 'raw', _key: key(), markdown: source });
        return `\n\n${placeholder}\n\n`;
    });
    const source = richSource.replace(/^(===|\|\|\|)\s*\[([^\]\n]+)\]\s*\n([\s\S]*?)^\1\s*$/gm, (_match, delimiter, title, body) => {
        const placeholder = `TERRADOCSBLOCK${blocks.length}PLACEHOLDER`;
        blocks.push({
            _type: delimiter === '===' ? 'accordion' : 'tabs',
            _key: key(),
            items: [{ title, markdown: body, content: [] }],
            markdown: _match,
        });
        return `\n\n${placeholder}\n\n`;
    });
    const parsed = marked.lexer(source, { gfm: true });
    const result = [];
    for (const token of parsed) {
        if (token.type === 'space')
            continue;
        const marker = token.raw.trim().match(/^TERRADOCSBLOCK(\d+)PLACEHOLDER$/);
        if (marker) {
            const block = blocks[Number(marker[1])];
            if (block)
                result.push(block);
            continue;
        }
        if (token.type === 'heading') {
            result.push(textBlock(`h${Math.min(6, Math.max(2, token.depth ?? 2))}`, token.tokens, token.text ?? ''));
            continue;
        }
        if (token.type === 'paragraph' && !/\n\s*\n/.test(token.raw)) {
            result.push(textBlock('normal', token.tokens, token.text ?? ''));
            continue;
        }
        if (token.type === 'blockquote') {
            result.push(textBlock('blockquote', token.tokens, token.text ?? ''));
            continue;
        }
        if (token.type === 'code') {
            result.push({
                _type: 'code',
                _key: key(),
                language: token.lang ?? '',
                value: token.text ?? '',
            });
            continue;
        }
        result.push({ _type: 'raw', _key: key(), markdown: token.raw });
    }
    return result;
}
/** Serialize supported visual blocks and keep every opaque raw token verbatim. */
export function docsValueToMarkdown(value) {
    return (value
        .map((block) => {
        const item = block;
        const extra = Object.keys(item).some((name) => ![
            '_type',
            '_key',
            'markdown',
            'language',
            'source',
            'value',
            'items',
            'code',
            'inline',
        ].includes(name));
        if (item._type === 'block') {
            const markDefs = new Map((Array.isArray(item.markDefs) ? item.markDefs : [])
                .filter((mark) => typeof mark === 'object' && mark !== null && '_key' in mark && 'href' in mark)
                .map((mark) => [mark._key, mark.href]));
            const children = Array.isArray(item.children)
                ? item.children
                : [];
            const content = children
                .map((child) => {
                if (child._type === 'math')
                    return `$${child.code ?? ''}$`;
                let text = child.text ?? '';
                for (const mark of child.marks ?? []) {
                    if (mark === 'strong')
                        text = `**${text}**`;
                    if (mark === 'em')
                        text = `*${text}*`;
                    if (mark === 'strike-through')
                        text = `~~${text}~~`;
                    if (mark === 'code')
                        text = `\`${text}\``;
                    if (markDefs.has(mark))
                        text = `[${text}](${markDefs.get(mark)})`;
                }
                return text;
            })
                .join('');
            const style = String(item.style ?? 'normal');
            if (/^h[2-6]$/.test(style))
                return `${'#'.repeat(Number(style[1]))} ${content}`;
            if (style === 'blockquote')
                return `> ${content}`;
            return content;
        }
        if (item._type === 'raw' && !extra)
            return String(item.markdown ?? '');
        if (item._type === 'code' && !extra)
            return `\`\`\`${String(item.language ?? '')}\n${String(item.value ?? '')}\n\`\`\``;
        if (item._type === 'accordion' || item._type === 'tabs') {
            if (item.markdown)
                return item.markdown;
            const delimiter = item._type === 'accordion' ? '===' : '|||';
            return (Array.isArray(item.items) ? item.items : [])
                .map((entry) => `${delimiter}[${entry.title ?? 'Item'}]\n${entry.markdown ?? ''}\n${delimiter}`)
                .join('\n\n');
        }
        return `:::terra-docs ${item._type}\n${JSON.stringify(item)}\n:::`;
    })
        .join('\n\n')
        .replace(/\n{3,}/g, '\n\n')
        .trimEnd() + '\n');
}
//# sourceMappingURL=markdown-model.js.map