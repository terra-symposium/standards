import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { Button, ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuSeparator, ContextMenuTrigger, DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger, Input, Select, SelectContent, SelectItem, SelectTrigger, SelectValue, ToggleGroup, ToggleGroupItem, } from '@terra-symposium/styling/ui';
import { DocumentAttachment, Download, Link, OverflowMenuVertical, TrashCan, } from '@carbon/icons-react';
function attachmentKind(attachment) {
    const type = attachment.type?.toLowerCase() ?? '';
    const path = attachment.href.toLowerCase().split('?')[0] ?? '';
    if (type.startsWith('image/') || /\.(png|jpe?g|gif|webp|svg)$/.test(path))
        return 'Images';
    if (type.startsWith('video/') || /\.(mp4|webm|mov)$/.test(path))
        return 'Videos';
    if (type === 'text/html' ||
        (/^(https?:)?\/\//.test(attachment.href) && !path.match(/\.[a-z0-9]+$/)))
        return 'Links';
    return 'Files';
}
function firstLeaf(section) {
    return section.groups.flatMap((group) => group.leaves)[0]?.href ?? '/';
}
function sectionForPath(sections, path) {
    return Math.max(0, sections.findIndex((section) => section.groups.some((group) => group.leaves.some((leaf) => leaf.href === path))));
}
export function DocsWorkspaceNavigation({ sections, currentPath, actions, }) {
    const [sectionIndex, setSectionIndex] = useState(() => sectionForPath(sections, currentPath));
    const [query, setQuery] = useState('');
    const [error, setError] = useState('');
    useEffect(() => setSectionIndex(sectionForPath(sections, currentPath)), [sections, currentPath]);
    const section = sections[sectionIndex];
    const groups = section?.groups ?? [];
    const run = (action) => {
        if (!actions?.available(action))
            return;
        if (action.name.startsWith('delete-') &&
            !window.confirm(`Delete ${action.leaf?.title ?? action.group?.title ?? action.section.title}? This action cannot be undone.`))
            return;
        setError('');
        void Promise.resolve(actions.perform(action)).catch((reason) => setError(reason instanceof Error ? reason.message : 'Action failed.'));
    };
    const leafAction = (name, group, leaf) => ({ name, section: section, group, leaf });
    const menuItems = (group, leaf, kind) => {
        const Item = kind === 'context' ? ContextMenuItem : DropdownMenuItem;
        const Separator = kind === 'context' ? ContextMenuSeparator : DropdownMenuSeparator;
        return (_jsxs(_Fragment, { children: [_jsx(Item, { onSelect: () => window.open(leaf.href, '_blank', 'noopener,noreferrer'), children: "Open in new tab" }), _jsxs(Item, { onSelect: () => {
                        void navigator.clipboard.writeText(new URL(leaf.href, window.location.href).href);
                    }, children: [_jsx(Link, { className: "size-4" }), "Copy link"] }), _jsxs(Item, { onSelect: () => {
                        sessionStorage.setItem('terra-docs:mode', 'attachments');
                        window.location.assign(leaf.href);
                    }, children: [_jsx(DocumentAttachment, { className: "size-4" }), "Attachments view"] }), actions &&
                    [
                        'move-leaf-up',
                        'move-leaf-down',
                        'move-leaf',
                        'rename-leaf',
                        'duplicate-leaf',
                        'manage-attachments',
                        'download-leaf',
                        'delete-leaf',
                    ]
                        .filter((name) => actions.available(leafAction(name, group, leaf)))
                        .map((name, index) => (_jsxs("span", { children: [index === 0 && _jsx(Separator, {}), _jsx(Item, { onSelect: () => run(leafAction(name, group, leaf)), children: name === 'move-leaf-up' ? ('Move up') : name === 'move-leaf-down' ? ('Move down') : name === 'move-leaf' ? ('Move to group') : name === 'rename-leaf' ? ('Rename page') : name === 'duplicate-leaf' ? ('Duplicate page') : name === 'manage-attachments' ? ('Manage attachments') : name === 'download-leaf' ? (_jsxs(_Fragment, { children: [_jsx(Download, { className: "size-4" }), "Download page"] })) : (_jsxs(_Fragment, { children: [_jsx(TrashCan, { className: "size-4" }), "Delete page"] })) })] }, name)))] }));
    };
    return (_jsxs("nav", { className: "terra-docs-workspace-nav", "aria-label": "Documentation", children: [_jsx("label", { className: "terra-docs-control-label", htmlFor: "terra-docs-section", children: "Section" }), _jsxs("div", { className: "terra-docs-workspace-section-select", children: [_jsxs(Select, { value: String(sectionIndex), onValueChange: (value) => {
                            const index = Number(value);
                            setSectionIndex(index);
                            setQuery('');
                            const href = sections[index] && firstLeaf(sections[index]);
                            if (href)
                                window.location.assign(href);
                        }, children: [_jsx(SelectTrigger, { id: "terra-docs-section", "aria-label": "Section", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: sections.map((entry, index) => (_jsx(SelectItem, { value: String(index), children: entry.title }, `${entry.title}-${index}`))) })] }), section && actions && (_jsxs(DropdownMenu, { children: [_jsx(DropdownMenuTrigger, { asChild: true, children: _jsx(Button, { variant: "ghost", size: "xs", "aria-label": `Actions for section ${section.title}`, children: _jsx(OverflowMenuVertical, { size: 16 }) }) }), _jsx(DropdownMenuContent, { children: ['rename-section', 'download-section', 'delete-section']
                                    .filter((name) => actions.available({ name, section }))
                                    .map((name) => (_jsx(DropdownMenuItem, { onSelect: () => run({ name, section }), children: name === 'rename-section'
                                        ? 'Rename section'
                                        : name === 'download-section'
                                            ? 'Download section'
                                            : 'Delete section' }, name))) })] }))] }), _jsx(Input, { "aria-label": "Search pages", placeholder: "Search pages", value: query, onChange: (event) => setQuery(event.currentTarget.value) }), error && _jsx("p", { role: "alert", children: error }), _jsx("div", { className: "terra-docs-workspace-groups", children: groups
                    .filter((group) => !query ||
                    group.title.toLowerCase().includes(query.toLowerCase()) ||
                    group.leaves.some((leaf) => leaf.title.toLowerCase().includes(query.toLowerCase())))
                    .map((group, index) => (_jsxs("div", { className: "terra-docs-workspace-group", children: [_jsxs("div", { className: "terra-docs-workspace-group-heading", children: [_jsx("h2", { children: group.title }), actions && (_jsxs(DropdownMenu, { children: [_jsx(DropdownMenuTrigger, { asChild: true, children: _jsx(Button, { variant: "ghost", size: "xs", "aria-label": `Actions for group ${group.title}`, children: _jsx(OverflowMenuVertical, { size: 16 }) }) }), _jsx(DropdownMenuContent, { children: [
                                                'create-leaf',
                                                'move-group-up',
                                                'move-group-down',
                                                'rename-group',
                                                'delete-group',
                                            ]
                                                .filter((name) => actions.available({ name, section: section, group }))
                                                .map((name) => (_jsx(DropdownMenuItem, { onSelect: () => run({ name, section: section, group }), children: name === 'create-leaf'
                                                    ? 'New page'
                                                    : name === 'move-group-up'
                                                        ? 'Move group up'
                                                        : name === 'move-group-down'
                                                            ? 'Move group down'
                                                            : name === 'rename-group'
                                                                ? 'Rename group'
                                                                : 'Delete group' }, name))) })] }))] }), _jsx("ul", { children: group.leaves
                                .filter((leaf) => !query ||
                                group.title.toLowerCase().includes(query.toLowerCase()) ||
                                leaf.title.toLowerCase().includes(query.toLowerCase()))
                                .map((leaf, leafIndex) => (_jsxs("li", { children: [_jsxs(ContextMenu, { children: [_jsx(ContextMenuTrigger, { asChild: true, children: _jsx("a", { href: leaf.href, "aria-current": leaf.href === currentPath ? 'page' : undefined, children: leaf.title }) }), _jsx(ContextMenuContent, { children: menuItems(group, leaf, 'context') })] }), _jsxs(DropdownMenu, { children: [_jsx(DropdownMenuTrigger, { asChild: true, children: _jsx(Button, { variant: "ghost", size: "xs", "aria-label": `Actions for ${leaf.title}`, children: _jsx(OverflowMenuVertical, { size: 16 }) }) }), _jsx(DropdownMenuContent, { children: menuItems(group, leaf, 'dropdown') })] })] }, `${leaf.href}-${leafIndex}`))) })] }, `${group.title}-${index}`))) }), groups.length === 0 && _jsx("p", { className: "terra-docs-empty", children: "No pages in this section." })] }));
}
export function DocsWorkspaceToolbar({ attachments = [], capabilities = {}, onEdit, onSave, onHistory, onPublish, remoteProvider, onModeChange, }) {
    const [mode, setMode] = useState('view');
    const [attachmentFilter, setAttachmentFilter] = useState('All');
    const attachmentTypes = [...new Set(attachments.map(attachmentKind))];
    useEffect(() => {
        const requested = sessionStorage.getItem('terra-docs:mode');
        if (requested === 'attachments') {
            setMode('attachments');
            onModeChange?.('attachments');
            sessionStorage.removeItem('terra-docs:mode');
        }
    }, [onModeChange]);
    useEffect(() => {
        const element = document.querySelector('.terra-docs-site');
        if (element)
            element.dataset.docsMode = mode;
        return () => {
            if (element)
                delete element.dataset.docsMode;
        };
    }, [mode]);
    return (_jsxs("div", { className: "terra-docs-workspace-toolbar", role: "toolbar", "aria-label": "Document controls", "data-can-edit": Boolean(capabilities.edit && remoteProvider), children: [_jsxs(Select, { size: "xs", value: mode, onValueChange: (value) => {
                    const next = value;
                    setMode(next);
                    onModeChange?.(next);
                    if (next === 'edit')
                        onEdit?.();
                }, children: [_jsx(SelectTrigger, { "aria-label": "Mode", children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "view", children: "View" }), capabilities.edit && remoteProvider && _jsx(SelectItem, { value: "edit", children: "Edit" }), _jsx(SelectItem, { value: "attachments", children: "Attachments" })] })] }), mode === 'attachments' && attachmentTypes.length > 1 && (_jsx(ToggleGroup, { type: "single", value: attachmentFilter, onValueChange: (value) => {
                    const next = value || 'All';
                    setAttachmentFilter(next);
                    window.dispatchEvent(new CustomEvent('terra-docs:attachment-filter', { detail: next }));
                }, "aria-label": "Filter attachments", children: ['All', ...attachmentTypes].map((kind) => (_jsx(ToggleGroupItem, { value: kind, size: "sm", children: kind }, kind))) })), mode === 'edit' && capabilities.save && (_jsx(Button, { type: "button", size: "xs", onClick: onSave, children: "Save" })), mode === 'edit' && capabilities.history && (_jsx(Button, { type: "button", size: "xs", variant: "ghost", onClick: onHistory, children: "History" })), mode === 'edit' && capabilities.publish && (_jsx(Button, { type: "button", size: "xs", variant: "tonal", onClick: onPublish, children: "Publish" }))] }));
}
export function DocsAttachmentsView({ attachments = [], onUpload, }) {
    const [filter, setFilter] = useState('All');
    useEffect(() => {
        const update = (event) => setFilter(event.detail);
        window.addEventListener('terra-docs:attachment-filter', update);
        return () => window.removeEventListener('terra-docs:attachment-filter', update);
    }, []);
    const visible = filter === 'All'
        ? attachments
        : attachments.filter((attachment) => attachmentKind(attachment) === filter);
    return (_jsxs("section", { className: "terra-docs-attachments-view", "aria-label": "Attachments", children: [_jsx("h2", { children: "Attachments" }), onUpload && (_jsxs("label", { className: "terra-docs-attachment-upload", children: ["Add attachment", ' ', _jsx("input", { type: "file", onChange: (event) => {
                            const file = event.currentTarget.files?.[0];
                            if (file)
                                void onUpload(file);
                            event.currentTarget.value = '';
                        } })] })), visible.length ? (_jsx("ul", { children: visible.map((attachment, index) => (_jsxs("li", { children: [_jsx("a", { href: attachment.href, target: "_blank", rel: "noopener noreferrer", children: attachment.title }), attachment.type && _jsx("span", { children: attachment.type })] }, `${attachment.href}-${index}`))) })) : (_jsx("p", { children: "No attachments found." }))] }));
}
//# sourceMappingURL=workspace.js.map