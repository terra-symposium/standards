import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Link, Redo, TextBold, TextItalic, TextStrikethrough, TextUnderline, Undo, } from '@carbon/icons-react';
import { useEditor, useEditorSelector } from '@portabletext/editor';
import { getActiveStyle, isActiveAnnotation, isActiveDecorator, } from '@portabletext/editor/selectors';
import { Button, Input, Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from '@terra-symposium/styling/ui';
import { useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { safeLink, schema } from './schema.js';
import { defaultDocsBlock, enabledDocsBlocks } from './blocks.js';
/** Terra's style dropdown and Carbon formatting controls, without website UI dependencies. */
export function Toolbar({ blocks }) {
    const editor = useEditor();
    const snapshot = useEditorSelector(editor, (state) => state);
    const selection = useRef(null);
    const linkDialog = useRef(null);
    const linkId = useId();
    const [linkValue, setLinkValue] = useState('');
    const [linkError, setLinkError] = useState(false);
    const [blockSelection, setBlockSelection] = useState('');
    const [slot, setSlot] = useState(null);
    useEffect(() => setSlot(document.querySelector('.terra-docs-formatting-slot')), []);
    const controls = (_jsxs("div", { className: "terra-docs-toolbar", role: "toolbar", "aria-label": "Editor controls", children: [_jsxs(Select, { value: getActiveStyle(snapshot) ?? 'normal', onValueChange: (style) => {
                    if (selection.current)
                        editor.send({ type: 'select', at: selection.current });
                    editor.send({ type: 'style.toggle', style });
                    editor.send({ type: 'focus' });
                }, children: [_jsx(SelectTrigger, { className: "terra-docs-select", "aria-label": "Block type", onPointerDownCapture: () => {
                            selection.current = editor.getSnapshot().context.selection;
                        }, onKeyDownCapture: () => {
                            selection.current = editor.getSnapshot().context.selection;
                        }, children: _jsx(SelectValue, { placeholder: "Text" }) }), _jsx(SelectContent, { className: "terra-docs-select-menu", position: "popper", sideOffset: 8, onCloseAutoFocus: (event) => event.preventDefault(), children: schema.styles.map(({ name, title }) => (_jsx(SelectItem, { value: name, className: "terra-docs-select-item", children: title }, name))) })] }), _jsx("span", { className: "terra-docs-toolbar-divider", "aria-hidden": "true" }), [
                { Icon: TextBold, name: 'strong', label: 'Bold' },
                { Icon: TextItalic, name: 'em', label: 'Italic' },
                { Icon: TextUnderline, name: 'underline', label: 'Underline' },
                { Icon: TextStrikethrough, name: 'strike-through', label: 'Strikethrough' },
            ].map(({ Icon, name, label }) => (_jsx(Button, { type: "button", variant: "ghost", size: "xs", "aria-label": label, title: label, "aria-pressed": isActiveDecorator(name)(snapshot), onMouseDown: (event) => event.preventDefault(), onClick: () => {
                    editor.send({ type: 'decorator.toggle', decorator: name });
                    editor.send({ type: 'focus' });
                }, children: _jsx(Icon, { size: 16, "aria-hidden": "true" }) }, name))), _jsx(Button, { type: "button", variant: "ghost", size: "xs", "aria-label": "Link", title: "Link", "aria-pressed": isActiveAnnotation('link')(snapshot), onMouseDown: (event) => event.preventDefault(), onClick: () => {
                    selection.current = editor.getSnapshot().context.selection;
                    setLinkValue('');
                    setLinkError(false);
                    linkDialog.current?.showModal();
                }, children: _jsx(Link, { size: 16, "aria-hidden": "true" }) }), _jsxs(Select, { value: blockSelection, onValueChange: (value) => {
                    const type = value;
                    if (!type)
                        return;
                    editor.send({
                        type: 'insert.block object',
                        blockObject: { name: type, value: defaultDocsBlock(type) },
                        placement: 'after',
                    });
                    setBlockSelection('');
                    editor.send({ type: 'focus' });
                }, children: [_jsx(SelectTrigger, { "aria-label": "Insert rich block", children: _jsx(SelectValue, { placeholder: "Insert block" }) }), _jsx(SelectContent, { children: enabledDocsBlocks(blocks).map((type) => (_jsx(SelectItem, { value: type, children: type }, type))) })] }), blocks?.inlineMath !== false && (_jsx(Button, { type: "button", variant: "ghost", size: "xs", "aria-label": "Insert inline math", title: "Insert inline math", onClick: () => {
                    editor.send({
                        type: 'insert.inline object',
                        inlineObject: { name: 'math', value: { code: 'E = mc^2', inline: true } },
                    });
                    editor.send({ type: 'focus' });
                }, children: "\u2211" })), _jsx(Button, { type: "button", variant: "ghost", size: "xs", "aria-label": "Undo", title: "Undo", onMouseDown: (event) => event.preventDefault(), onClick: () => {
                    editor.send({ type: 'history.undo' });
                    editor.send({ type: 'focus' });
                }, children: _jsx(Undo, { size: 16, "aria-hidden": "true" }) }), _jsx(Button, { type: "button", variant: "ghost", size: "xs", "aria-label": "Redo", title: "Redo", onMouseDown: (event) => event.preventDefault(), onClick: () => {
                    editor.send({ type: 'history.redo' });
                    editor.send({ type: 'focus' });
                }, children: _jsx(Redo, { size: 16, "aria-hidden": "true" }) }), _jsx("dialog", { ref: linkDialog, className: "terra-docs-link-dialog", "aria-labelledby": `${linkId}-title`, children: _jsxs("form", { onSubmit: (event) => {
                        event.preventDefault();
                        const href = safeLink(linkValue);
                        if (!href) {
                            setLinkError(true);
                            return;
                        }
                        if (selection.current)
                            editor.send({ type: 'select', at: selection.current });
                        editor.send({ type: 'annotation.add', annotation: { name: 'link', value: { href } } });
                        linkDialog.current?.close();
                        editor.send({ type: 'focus' });
                    }, children: [_jsx("h2", { id: `${linkId}-title`, children: "Add link" }), _jsx("label", { htmlFor: `${linkId}-url`, children: "URL" }), _jsx(Input, { id: `${linkId}-url`, autoFocus: true, required: true, value: linkValue, onChange: (event) => setLinkValue(event.currentTarget.value), placeholder: "https://example.com" }), linkError && _jsx("p", { role: "alert", children: "Enter a valid web, email, or relative URL." }), _jsxs("div", { children: [_jsx(Button, { type: "button", variant: "ghost", onClick: () => {
                                        linkDialog.current?.close();
                                        editor.send({ type: 'focus' });
                                    }, children: "Cancel" }), _jsx(Button, { type: "submit", children: "Add link" })] })] }) })] }));
    return slot ? createPortal(controls, slot) : controls;
}
//# sourceMappingURL=_Toolbar.js.map