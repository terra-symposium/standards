/**
 * astro/src/components/flow/_chrome.tsx
 * Shared React Flow presentation primitives.
 */
import type { ArcCanvasEls, ArcCanvasNodeData, ArcFn, ArcGraph, ArcGraphEdge, FlowAdapter, FlowCtxMenuState, FlowEdgeData, FlowNodeLike, FlowProblem, FlowProblemNodeData, FlowSize, Pos } from '../runtime/types.js';
import type { GroupNodeData } from '../runtime/types.js';
import type { ComponentPropsWithoutRef, ComponentType, ElementType, MouseEvent, ReactNode } from 'react';
import type { Connection, Edge, EdgeChange, EdgeProps, Node, NodeChange, NodeProps, PanelPosition, ReactFlowInstance, XYPosition } from '@xyflow/react';
import type { Problem } from '../runtime/types.js';
/**
 * Owns generic graph changes while adapters retain domain persistence.
 *
 * @param props - Flow adapter and editability flag.
 * @param adapter - Persistence adapter that reads and writes the graph state.
 * @param disabled - Disabled state controlling whether use editor accepts interaction.
 *
 * @return The current editor state and mutation helpers.
 */
export declare function useEditor<N extends Node = Node, E extends Edge = Edge>({ adapter, disabled }: {
    adapter: FlowAdapter<N, E>;
    disabled?: boolean;
}): any;
/**
 * Reads a persisted custom position from node data when one is available.
 *
 * @param n - Node-like value with optional custom position metadata.
 *
 * @return The stored position when it is valid, otherwise `undefined`.
 */
export declare function getCustomPos(n: FlowNodeLike): XYPosition | undefined;
/**
 * Resolves a node's structural group id from its parent or embedded data.
 *
 * @param n - Node-like value with optional parent metadata.
 *
 * @return The resolved group id when present, otherwise `undefined`.
 */
export declare function getGroupId(n: {
    parentId?: string | null;
    data?: unknown;
}): string | undefined;
/**
 * Measures a flow node using persisted dimensions, runtime measurements, or defaults.
 *
 * @param n - Node whose size is being resolved.
 * @param defaults - Fallback dimensions used when the node has not been measured.
 * @param extraHeight - Optional height override for nodes with dynamic content.
 *
 * @return The computed width and height used by layout.
 */
export declare function getNodeSize(n: FlowNodeLike, defaults?: {
    width: number;
    height: number;
    groupWidth?: number;
    groupHeight?: number;
    erdWidth?: number;
    erdHeight?: number;
}, extraHeight?: (n: FlowNodeLike) => number | undefined): FlowSize;
/**
 * Creates the stable Arc layout used by both the editor and read-only canvas.
 *
 * @param customLayout - Optional host layout override.
 *
 * @return A layout callback for Arc nodes.
 */
export declare function useArcNodeLayout(customLayout?: (nodes: Node<ArcCanvasNodeData>[], edges: Edge<FlowEdgeData>[]) => Node<ArcCanvasNodeData>[]): (nodes: Node<ArcCanvasNodeData>[], edges: Edge<FlowEdgeData>[]) => Node<ArcCanvasNodeData>[];
/**
 * Lays out a graph with Dagre and reprojects the result back to the node model.
 *
 * @param nodes - Nodes to position.
 * @param edges - Graph connections rendered and updated by layout graph.
 * @param direction - Layout direction that arranges layout graph's graph.
 * @param nodeSep - Spacing between nodes on the same rank.
 * @param rankSep - Spacing between ranks.
 * @param opts - Layout hooks that adapt the generic Dagre result to the caller's node model.
 *
 * @returns Positioned nodes and the resulting graph height.
 */
export { layoutGraph } from './_layout.js';
/**
 * Renders all handles for a node based on editability and required directions.
 *
 * @param props - Editable state and source/target handle positions that determine which connection points are active.
 * @param sources - Required source handle directions.
 * @param tgts - Required target handle directions.
 * @param editable - Editability flag controlling whether handles accepts changes.
 *
 * @return The full handle set for a node.
 */
export declare function Handles({ editable, sources: srcs, tgts }: {
    editable?: boolean;
    sources?: Pos[];
    tgts?: Pos[];
}): JSX.Element;
/**
 * Renders the compact skeleton card used while a flow is resolving.
 *
 * @param props - Polymorphic card props.
 * @param as - As input supplied to skeleton card's operation.
 * @param className - Additional CSS classes merged into skeleton card.
 * @param style - Inline style values merged into skeleton card.
 *
 * @return The loading skeleton card.
 */
export declare function SkeletonCard<T extends ElementType = 'div'>({ as, className, style, ...props }: {
    as?: T;
    className?: string;
} & Omit<ComponentPropsWithoutRef<T>, 'as' | 'className' | 'children'>): JSX.Element;
export { useEditor as useFlowEditor };
/**
 * Renders the common Arc logic body through the active workspace skin.
 *
 * @param props - Flow node props.
 * @param data - Logic node data.
 *
 * @return The rendered logic node body.
 */
export declare function LogicNode({ id, data }: NodeProps<Node<ArcCanvasNodeData>>): JSX.Element;
/**
 * Supplies the standard React Flow control panel with Carbon icons.
 *
 * @param props - Panel position and disable flag.
 * @param position - React Flow control-panel placement.
 * @param disabled - Disabled state controlling whether zoom controls accepts interaction.
 *
 * @return The zoom control cluster.
 */
export declare function ZoomControls({ position: pos, disabled }: {
    position: PanelPosition;
    disabled?: boolean;
}): JSX.Element;
/**
 * Renders the shared floating context menu shell used by flow hosts.
 *
 * @param props - Menu state and content.
 * @param state - Current menu position and visibility.
 * @param children - Menu contents rendered inside the shell.
 *
 * @return The floating context menu when visible, otherwise `null`.
 */
declare function FloatingMenu({ state, children }: {
    state: FlowCtxMenuState;
    children: ReactNode;
}): JSX.Element | null;
export { FloatingMenu as FlowContextMenu };
/**
 * Renders the loading affordance shown while a model adapter resolves graph state.
 *
 * @return The shared loading skeleton.
 */
export declare function Skeleton(): JSX.Element;
/**
 * Serializes an Arc flow canvas back into the graph model.
 *
 * @param flow - Flow canvas state.
 * @param prev - Prev input supplied to arc graph from's operation.
 *
 * @return The serialized Arc graph.
 */
export declare function arcGraphFrom(flow: {
    nodes: (FlowNodeLike & {
        data: ArcCanvasNodeData;
    })[];
    edges: {
        id: string;
        source: string;
        target: string;
        sourceHandle?: string | null | undefined;
        data?: FlowEdgeData | undefined;
        functions?: ArcFn[];
        handle?: string;
    }[];
}, prev: ArcGraph): ArcGraph;
/**
 * Renders the shared Arc canvas while hosts provide only policy and persistence callbacks.
 *
 * @param props - Arc elements, node renderers, layout function, labels, duration/hierarchy settings, and graph interaction callbacks.
 * @param elements - Graph elements supplied to arc canvas for layout and rendering.
 * @param annotationNodeTypes - Annotation node renderers available to arc canvas.
 * @param arrangeIcon - Arrange icon input supplied to arc canvas's operation.
 * @param editable - Editability flag controlling whether arc canvas accepts changes.
 * @param readOnly - Editability flag that prevents graph mutations in arc canvas.
 * @param onArrange - Callback invoked for arrange.
 * @param onConnect - Callback invoked with a new connection created in arc canvas.
 * @param onEdgesChange - Callback invoked with the updated edge changes from arc canvas.
 * @param onInit - Callback invoked for init.
 * @param onNodeClick - Callback invoked when a user selects a node in arc canvas.
 * @param onNodeContextMenu - Callback invoked for node context menu.
 * @param onNodesChange - Callback invoked with the updated node changes from arc canvas.
 * @param onPaneContextMenu - Callback invoked for pane context menu.
 * @param onProblemOpen - Callback invoked for problem open.
 * @param onProblemTitleChange - Callback invoked for problem title change.
 * @param onReady - Callback invoked when arc canvas finishes initialising its graph surface.
 * @param onResizeEnd - Callback invoked for resize end.
 *
 * @return The shared Arc canvas.
 */
export declare function ArcCanvas({ elements: els, annotationNodeTypes, arrangeIcon, arrangeLabel, editable, layoutNodes, readOnly, showDuration, showHierarchyControls, onArrange, onConnect, onEdgesChange, onInit, onNodeClick, onNodeContextMenu: onNodeCtxMenu, onNodesChange, onPaneContextMenu: onPaneCtxMenu, onProblemOpen, onProblemTitleChange, onReady, onResizeEnd, }: {
    elements: ArcCanvasEls;
    annotationNodeTypes?: Record<string, ComponentType<NodeProps<Node<GroupNodeData>>>>;
    arrangeIcon?: ReactNode;
    arrangeLabel?: string;
    editable?: boolean;
    layoutNodes?: (nodes: Node<ArcCanvasNodeData>[], edges: Edge<FlowEdgeData>[]) => Node<ArcCanvasNodeData>[];
    readOnly?: boolean;
    showDuration?: boolean;
    showHierarchyControls?: boolean;
    onArrange?: () => void;
    onConnect?: (connection: Connection) => void;
    onEdgesChange?: (changes: EdgeChange<Edge<FlowEdgeData>>[]) => void;
    onInit?: (instance: ReactFlowInstance<Node<ArcCanvasNodeData>, Edge<FlowEdgeData>>) => void;
    onNodeClick?: (_event: MouseEvent, node: Node<ArcCanvasNodeData>) => void;
    onNodeContextMenu?: (_event: MouseEvent, node: Node<ArcCanvasNodeData>) => void;
    onNodesChange?: (changes: NodeChange<Node<ArcCanvasNodeData>>[]) => void;
    onPaneContextMenu?: (_event: globalThis.MouseEvent | MouseEvent) => void;
    onProblemOpen?: (problem: FlowProblem) => void;
    onProblemTitleChange?: (nodeId: string, title: string) => void;
    onReady?: () => void;
    onResizeEnd?: (nodeId: string, params: {
        x: number;
        y: number;
        width: number;
        height: number;
    }) => void;
}): JSX.Element;
/**
 * Expands a persisted Arc into the one canonical node and edge projection.
 *
 * @param graph - Persisted Arc graph to expand.
 * @param problems - Problems input supplied to arc canvas elements's operation.
 * @param edgeData - Optional mapper that builds rendered edge metadata from a persisted edge and its source problem.
 *
 * @return The canonical canvas elements.
 */
export declare function arcCanvasElements(graph: ArcGraph, problems: Problem[], edgeData?: (edge: ArcGraphEdge, src: Problem | undefined) => FlowEdgeData): ArcCanvasEls;
/**
 * Renders shared labelled Arc edges while the skin controls node primitives.
 *
 * @param props - Arc edge props.
 * @param id - Identifier tying arc edge's output to its source record.
 * @param source - Source node identifier for the connection drawn by arc edge.
 * @param srcHandleId - Connection handle identifier supplied to arc edge.
 * @param srcX - Horizontal connection coordinate supplied to arc edge.
 * @param srcY - Vertical connection coordinate supplied to arc edge.
 * @param srcPos - Connection anchor position supplied to arc edge.
 * @param target - Target node identifier for the connection drawn by arc edge.
 * @param tgtHandleId - Connection handle identifier supplied to arc edge.
 * @param tgtX - Horizontal connection coordinate supplied to arc edge.
 * @param tgtY - Vertical connection coordinate supplied to arc edge.
 * @param tgtPosition - Connection anchor position supplied to arc edge.
 * @param data - Data record supplied to arc edge.
 *
 * @return The rendered edge path and label layer.
 */
export declare function ArcEdge({ id, source: src, sourceHandleId: srcHandleId, sourceX: srcX, sourceY: srcY, sourcePosition: srcPos, target: tgt, targetHandleId: tgtHandleId, targetX: tgtX, targetY: tgtY, targetPosition: tgtPos, data, }: EdgeProps<Edge<FlowEdgeData>>): JSX.Element;
/**
 * Renders the common problem card, its handles, title editing, and route affordances.
 *
 * @param props - Problem node props.
 * @param id - Identifier tying problem node's output to its source record.
 * @param data - Problem card data and callbacks.
 * @param selected - Boolean flag controlling problem node's selected behaviour.
 *
 * @return The rendered problem node.
 */
export declare function ProblemNode({ id, data, selected }: NodeProps<Node<FlowProblemNodeData>>): JSX.Element;
//# sourceMappingURL=_chrome.d.ts.map