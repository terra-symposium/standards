/** Docs table renderer with view and edit modes. */
import type { DocsBlock, PortableTextBlockRendererProps } from '../types.js';
/** Sanity Portable Text table rows and headers. */
type TableBlock = DocsBlock<'table'>;
/** Adapts Portable Text's block-object contract to the table renderer.
 *
 * @param props - Portable Text renderer attributes, nested children, table node, path, and read-only mode.
 * @returns The table renderer in editable or read-only mode.
 */
export declare function renderTable({ attributes: attrs, children, node, path, readOnly }: PortableTextBlockRendererProps<TableBlock>): React.JSX.Element;
export {};
//# sourceMappingURL=_Table.d.ts.map