/**
 * astro/src/components/editor/docs/heading.tsx
 * Shared Docs heading identifiers and copyable read-only headings.
 */
import type { ReactNode } from 'react';
/**
 * Normalizes text into the URL identifier used by Docs headings and their table of contents.
 *
 * @param text - The heading text to normalize.
 * @returns The heading's URL fragment.
 */
export declare const toHeadingId: (text: string) => string;
/**
 * Renders a Docs heading with a keyboard-accessible control for copying its link.
 *
 * @param props - The heading level and its content.
 * @returns A heading with a copy-link button.
 */
export declare function DocsHeading({ children, level }: {
    children: ReactNode;
    level: 'h2' | 'h3' | 'h4' | 'h5' | 'h6';
}): React.JSX.Element;
//# sourceMappingURL=heading.d.ts.map