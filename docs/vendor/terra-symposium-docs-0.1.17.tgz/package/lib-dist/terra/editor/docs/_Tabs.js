import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/** Docs tabs and accordion renderer with view and edit modes. */
import { useEditor } from '@portabletext/editor';
import { AccordionGroup, AccordionItem, TabsGroup, TabsItem } from '../_blocks.js';
import { Add as AddIcon } from '@carbon/icons-react';
import { ErrorBoundary } from '../../runtime/ui.js';
import { Button } from '@terra-symposium/styling/ui/terra-original';
import { TerraContentEditor } from '../TerraContentEditor.js';
const key = (val, fallback) => (typeof val === 'object' && val !== null && typeof val._key === 'string' ? val._key : fallback);
/** Renders read-only Docs tabs.
 *
 * @param props - Authored tabs block containing labeled sections and their nested content.
 * @returns The tabbed content panel.
 */
/**
 * Renders the TabsBlock component.
 *
 * @param props - Authored tab block with labeled nested sections to render.
 * @returns The read-only tab group.
 */
function TabsBlock({ block }) {
    return (_jsx(ErrorBoundary, { name: 'TabsBlock', children: _jsx(TabsGroup, { children: (block.items ?? []).map((i, v) => {
                const entry = i;
                return (_jsx(TabsItem, { title: typeof entry.title === 'string' ? entry.title : `Tab ${v + 1}`, children: _jsx(TerraContentEditor, { content: (Array.isArray(entry.content) ? entry.content : []), docsAttachments: [], memberProfile: 'docs', nested: true, readOnly: true }) }, key(i, `${v}`)));
            }) }) }));
}
Object.assign(TabsBlock, { displayName: 'DocsTabsBlock' });
/** Renders read-only Docs accordion sections. */
/**
 * Renders the AccordionBlock component.
 *
 * @param props - Authored accordion block with labeled expandable sections to render.
 * @returns The read-only accordion group.
 */
function AccordionBlock({ block }) {
    return (_jsx(ErrorBoundary, { name: 'AccordionBlock', children: _jsx(AccordionGroup, { children: (block.items ?? []).map((i, v) => {
                const entry = i;
                return (_jsx(AccordionItem, { title: typeof entry.title === 'string' ? entry.title : `Item ${v + 1}`, children: _jsx(TerraContentEditor, { content: (Array.isArray(entry.content) ? entry.content : []), docsAttachments: [], memberProfile: 'docs', nested: true, readOnly: true }) }, key(i, `${v}`)));
            }) }) }));
}
Object.assign(AccordionBlock, { displayName: 'DocsAccordionBlock' });
/** Shares tab and accordion mutations while preserving their component-local renderers. */
/**
 * Renders the SectionsEditor component.
 *
 * @param props - Portable Text editor attributes, nested children, section kind, block node, and path.
 * @returns The editor controls for tabs or accordion sections.
 */
/**
 * Renders the Sections component.
 *
 * @param props - Authored tabs or accordion block selected for read-only display.
 * @returns The matching tabs or accordion group.
 */
function SectionsEditor({ attributes: attrs, children, kind, node, path }) {
    const editor = useEditor();
    const items = node.items ?? [];
    const rename = (idx, title) => editor.send({ type: 'block.set', at: path, props: { items: items.map((i, c) => (c === idx ? { ...i, title } : i)) } });
    const remove = (idx) => editor.send({ type: 'block.set', at: path, props: { items: items.filter((_item, c) => c !== idx) } });
    const add = () => editor.send({
        type: 'block.set',
        at: path,
        props: {
            items: [
                ...items,
                {
                    _key: crypto.randomUUID().replaceAll('-', ''),
                    _type: 'item',
                    content: [],
                    title: kind === 'tabs' ? `Tab ${items.length + 1}` : `Item ${items.length + 1}`,
                },
            ],
        },
    });
    const content = items.map((i, v) => {
        const title = typeof i.title === 'string' ? i.title : kind === 'tabs' ? `Tab ${v + 1}` : `Item ${v + 1}`;
        const nested = (_jsx(TerraContentEditor, { content: (i.content ?? []), docsAttachments: [], memberProfile: 'docs', nested: true, onChange: x => editor.send({ type: 'block.set', at: path, props: { items: items.map((i, c) => (c === v ? { ...i, content: x } : i)) } }) }));
        return kind === 'tabs' ? (_jsx(TabsItem, { title: title, children: nested }, i._key)) : (_jsx(AccordionItem, { title: title, onDelete: () => remove(v), onRename: x => rename(v, x), children: nested }, i._key));
    });
    return (_jsx(ErrorBoundary, { name: 'SectionsEditor', children: _jsxs("div", { ...attrs, contentEditable: false, "data-terra-block": kind, children: [kind === 'tabs' ? (_jsx(TabsGroup, { onAdd: add, onDelete: remove, onRename: (v, t) => rename(Number(v), t), children: content })) : (_jsxs(_Fragment, { children: [_jsx("div", { className: 'mb-2', children: _jsxs(Button, { size: 'sm', variant: 'outline', onClick: add, children: [_jsx(AddIcon, { "aria-hidden": 'true' }), " Add section"] }) }), _jsx(AccordionGroup, { children: content })] })), children] }) }));
}
Object.assign(SectionsEditor, { displayName: 'DocsSectionsEditor' });
/**
 * Renders Docs tabs or accordion sections from their authored block.
 *
 * @param props - Authored tabs or accordion block with its labeled nested sections.
 * @returns The matching tabbed or expandable section group.
 */
function Sections({ block }) {
    return block._type === 'tabs' ? _jsx(TabsBlock, { block: block }) : _jsx(AccordionBlock, { block: block });
}
Object.assign(Sections, { displayName: 'DocsSections' });
/** Adapts Portable Text's block-object contract to the sections renderer. */
/**
 * Renders the renderSections component.
 *
 * @param props - Portable Text renderer attributes, nested children, section node, path, and read-only mode.
 * @returns The sections renderer in editable or read-only mode.
 */
export function renderSections({ attributes: attrs, children, node, path, readOnly }) {
    return readOnly ? _jsx(Sections, { block: node }) : _jsx(SectionsEditor, { attributes: attrs, children: children, kind: node._type, node: node, path: path });
}
//# sourceMappingURL=_Tabs.js.map