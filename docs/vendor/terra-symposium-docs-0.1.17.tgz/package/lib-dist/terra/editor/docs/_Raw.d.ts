/**
 * astro/src/components/editor/docs/_Raw.tsx
 */
import type { DocsBlock } from '../types.js';
/**
 * Renders the raw component.
 *
 * @param props - Raw block props containing the authored markup.
 *
 * @return Rendered raw documentation content.
 */
export declare function Raw({ block }: {
    block: DocsBlock<'raw'>;
}): JSX.Element;
//# sourceMappingURL=_Raw.d.ts.map