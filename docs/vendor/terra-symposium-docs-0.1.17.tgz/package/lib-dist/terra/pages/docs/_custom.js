/** Mutated in place by a host before the workspace renders. */
export const components = [];
export function setDocsCustomComponents(next) {
    components.splice(0, components.length, ...next);
}
//# sourceMappingURL=_custom.js.map