/**
 * astro/src/pages/docs/_tree.tsx
 * Recursively rendering branch nodes composing the sidebar UI tree structure, alongside leaves and menus.
 * Folder boundary: recursive sidebar tree presentation only; sidebar state and dialogs remain in `_sidebar.tsx`.
 */
import React from 'react';
import type { DocsTreeMenuAction as MenuAction } from '../../runtime/types.js';
import type { DragState } from '../../runtime/types.js';
import type { Leaf as LeafNode, Mode, Tree as TreeType } from '../../runtime/types.js';
import type { ReorderDropState } from '../../runtime/types.js';
/**
 * Renders a standard ContextMenu with support for nested sub-actions and separators.
 *
 * @param props - Ordered menu actions, including labels, optional icons, disabled state, separators, and nested sub-actions.
 *
 * @return The context menu with the supplied actions and any nested menus.
 */
export declare function Menu({ actions }: {
    actions: MenuAction[];
}): JSX.Element;
export declare const Tree: ({ bPath, node, ctx, siblings: sibs, }: {
    bPath: string;
    node: TreeType;
    siblings?: TreeType[];
    ctx: {
        creating: boolean;
        transitioning: boolean;
        drag: DragState | null;
        dState: ReorderDropState | null;
        mode: Mode;
        mvBranch: (input: {
            fPath: string;
            pPath: string;
            tpath: string;
            tPosition?: "after" | "before";
            tTarget?: string;
        }) => Promise<void>;
        uploadAsLeaf: (files: FileList | File[] | null, tgtPath: string, pos: "before" | "after", tgtType: "file" | "folder") => Promise<void>;
        mvLeaf: (input: {
            path: string;
            tTarget?: string;
            tpath: string;
            tPosition?: "after" | "before";
        }) => Promise<void>;
        pathname: string;
        refreshTree: () => Promise<void>;
        shellPermission: "read" | "write";
        openCreate: (fPath: string, parentId: string) => void;
        addGroup: (fPath: string, sectionId: string) => void;
        setDrag: (drag: DragState | null) => void;
        setDState: (state: ReorderDropState | null) => void;
        setHovered: (val: string | null) => void;
        hovered: string | null;
        setInputDlg: (dlg: {
            open: boolean;
            title: string;
            description?: string;
            label: string;
            value: string;
            onSave: (val: string) => void;
            onCancel?: () => void;
        } | null) => void;
        setTree: React.Dispatch<React.SetStateAction<TreeType[]>>;
        getTree: () => TreeType[];
        findActiveLeaf: (nodes: TreeType[], tgtUrl: string) => LeafNode | null;
        setCPathname: React.Dispatch<React.SetStateAction<string>>;
        selectedLeaves: string[];
        handleSelect: (path: string, isCmd: boolean, isShift: boolean) => void;
        clearSelection: () => void;
        mergeLeaves: (paths: string[]) => void;
        setDelTarget: React.Dispatch<React.SetStateAction<{
            kind: "section" | "branch" | "leaf";
            path: string;
            bPath?: string;
            slugPath?: string;
            active?: boolean;
            title: string;
            origNode?: TreeType;
        } | null>>;
        setExportTarget: React.Dispatch<React.SetStateAction<{
            paths: string[];
            rootDir: string;
            filename: string;
            title: string;
            nodeIds?: string[];
        } | null>>;
        setManageAttTgt: React.Dispatch<React.SetStateAction<{
            path: string;
            title: string;
            scope: "section" | "group" | "leaf";
            node: TreeType;
        } | null>>;
        setAssetTarget: React.Dispatch<React.SetStateAction<{
            path: string;
            title: string;
        } | null>>;
    };
}) => JSX.Element;
declare const _default: ({ bPath, node, ctx, siblings: sibs, }: {
    bPath: string;
    node: TreeType;
    siblings?: TreeType[];
    ctx: {
        creating: boolean;
        transitioning: boolean;
        drag: DragState | null;
        dState: ReorderDropState | null;
        mode: Mode;
        mvBranch: (input: {
            fPath: string;
            pPath: string;
            tpath: string;
            tPosition?: "after" | "before";
            tTarget?: string;
        }) => Promise<void>;
        uploadAsLeaf: (files: FileList | File[] | null, tgtPath: string, pos: "before" | "after", tgtType: "file" | "folder") => Promise<void>;
        mvLeaf: (input: {
            path: string;
            tTarget?: string;
            tpath: string;
            tPosition?: "after" | "before";
        }) => Promise<void>;
        pathname: string;
        refreshTree: () => Promise<void>;
        shellPermission: "read" | "write";
        openCreate: (fPath: string, parentId: string) => void;
        addGroup: (fPath: string, sectionId: string) => void;
        setDrag: (drag: DragState | null) => void;
        setDState: (state: ReorderDropState | null) => void;
        setHovered: (val: string | null) => void;
        hovered: string | null;
        setInputDlg: (dlg: {
            open: boolean;
            title: string;
            description?: string;
            label: string;
            value: string;
            onSave: (val: string) => void;
            onCancel?: () => void;
        } | null) => void;
        setTree: React.Dispatch<React.SetStateAction<TreeType[]>>;
        getTree: () => TreeType[];
        findActiveLeaf: (nodes: TreeType[], tgtUrl: string) => LeafNode | null;
        setCPathname: React.Dispatch<React.SetStateAction<string>>;
        selectedLeaves: string[];
        handleSelect: (path: string, isCmd: boolean, isShift: boolean) => void;
        clearSelection: () => void;
        mergeLeaves: (paths: string[]) => void;
        setDelTarget: React.Dispatch<React.SetStateAction<{
            kind: "section" | "branch" | "leaf";
            path: string;
            bPath?: string;
            slugPath?: string;
            active?: boolean;
            title: string;
            origNode?: TreeType;
        } | null>>;
        setExportTarget: React.Dispatch<React.SetStateAction<{
            paths: string[];
            rootDir: string;
            filename: string;
            title: string;
            nodeIds?: string[];
        } | null>>;
        setManageAttTgt: React.Dispatch<React.SetStateAction<{
            path: string;
            title: string;
            scope: "section" | "group" | "leaf";
            node: TreeType;
        } | null>>;
        setAssetTarget: React.Dispatch<React.SetStateAction<{
            path: string;
            title: string;
        } | null>>;
    };
}) => JSX.Element;
export default _default;
//# sourceMappingURL=_tree.d.ts.map