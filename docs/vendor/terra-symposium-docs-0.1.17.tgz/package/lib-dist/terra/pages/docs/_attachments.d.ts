/**
 * astro/src/pages/docs/_attachments.tsx
 * Docs attachment collection, uploads, and attachment-specific context menus.
 */
import type { Tree as TreeType } from '../../runtime/types.js';
/**
 * Renders the document attachment manager for filtering, selecting, uploading, and organizing assets.
 *
 * @param props - The document path and current Docs tree used to scope and display its attachments.
 *
 * @return The attachment manager and its upload, selection, and organization controls.
 */
export declare function Attachments({ dPath, tree }: {
    dPath: string;
    tree: TreeType[];
}): JSX.Element;
export declare namespace Attachments {
    var displayName: string;
}
//# sourceMappingURL=_attachments.d.ts.map