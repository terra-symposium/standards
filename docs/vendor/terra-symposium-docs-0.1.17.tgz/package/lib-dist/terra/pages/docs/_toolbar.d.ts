/**
 * astro/src/pages/docs/_toolbar.tsx
 * Shared UI components, toolbars, and context menus for the visual MDX Editor.
 * Folder boundary: editor chrome and commands; document state, block rendering, and navigation remain outside this module.
 */
import type { EditorToolbarAdapter, PortableEditorBlock } from '../../runtime/types.js';
import type { Mode as ToolbarMode, ToolbarState } from '../../runtime/types.js';
export declare const DocsToolbarActions: ({ activeMode: aMode, editable, size, toolbar }: {
    activeMode: ToolbarMode;
    editable: boolean;
    size?: "sm" | "xs";
    toolbar: ToolbarState | null;
}) => JSX.Element | null;
export declare const Toolbar: ({ activeMode: aMode, editable, toolbar, blocks, adapter, docs, }: {
    activeMode?: ToolbarMode;
    editable: boolean;
    toolbar: ToolbarState | null;
    transitioning?: boolean;
    blocks?: PortableEditorBlock[];
    adapter?: EditorToolbarAdapter;
    docs?: boolean;
}) => JSX.Element | null;
//# sourceMappingURL=_toolbar.d.ts.map