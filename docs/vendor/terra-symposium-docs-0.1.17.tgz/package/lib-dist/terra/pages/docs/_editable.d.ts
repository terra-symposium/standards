/**
 * astro/src/pages/docs/_editable.tsx
 * JSON draft state and persistence provider for Docs View, Edit, and Attachments modes.
 */
import React from 'react';
import type { DocBody } from '../../runtime/types.js';
import type { DocsPermissionLevel as Permission, Mode, PathProps } from '../../runtime/types.js';
import type { ReactNode } from 'react';
/**
 * Renders the loader component.
 *
 * @param props - Optional styling for the loading indicator while a Docs route or editor is resolving.
 * @param className - Additional CSS classes merged into loader.
 *
 * @return The accessible loading indicator used by Docs transitions.
 */
export declare function Loader({ className }: {
    className?: string;
}): React.JSX.Element;
/**
 * Orchestrates layout math and hydration visibility to prevent FOUC during navigation.
 *
 * @param props - Child content, visual class, navigation mode, and optional route key for the Docs page transition.
 * @param children - Child content nested inside transition shell's rendered output.
 * @param className - Additional CSS classes merged into transition shell.
 * @param mode - Mode input supplied to transition shell's operation.
 * @param path - Source or route path resolved for transition shell.
 *
 * @return A transition wrapper that keeps page visibility synchronized with route hydration.
 */
export declare function TransitionShell({ children, className, mode, path }: {
    children: ReactNode;
    className?: string;
    mode: Mode | 'transitioning';
    path?: string;
}): React.JSX.Element;
/**
 * Renders the editable component.
 *
 * @param props - Document content, title, path, source, and permission state that determine whether the page is editable or read-only.
 * @param children - Child content nested inside editable's rendered output.
 * @param content - Content input supplied to editable's operation.
 * @param description - Supporting text shown in editable.
 * @param path - Source or route path resolved for editable.
 * @param permission - Permission input supplied to editable's operation.
 * @param pathname - Pathname input supplied to editable's operation.
 * @param title - Heading text shown in editable.
 * @param source - Source node identifier for the connection drawn by editable.
 *
 * @return The document editor or read-only view configured for the supplied document and permission.
 */
export default function Editable({ children, content, description, path, permission, pathname, title, source: src, }: PathProps & {
    children?: React.ReactNode;
    content?: DocBody;
    description?: string;
    path?: string;
    permission: Permission;
    source?: string;
    title?: string;
}): React.JSX.Element;
//# sourceMappingURL=_editable.d.ts.map