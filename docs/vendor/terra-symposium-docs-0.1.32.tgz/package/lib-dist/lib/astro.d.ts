/**
 * Vite dependencies that must be pre-bundled when an Astro React island loads
 * the published Docs package. Astro's island loader does not reliably expose
 * these package imports to Vite's dependency crawler, so both Docs entrypoints
 * and their nested CommonJS dependencies need explicit optimization.
 */
export declare const DOCS_VITE_OPTIMIZE_DEPS: readonly ["@terra-symposium/docs", "@terra-symposium/docs/local-workspace", "@terra-symposium/docs > @dagrejs/dagre", "@terra-symposium/docs > debug", "@terra-symposium/docs > sanitize-html", "@terra-symposium/docs > use-sync-external-store/shim", "@terra-symposium/docs > use-sync-external-store/shim/with-selector", "react/compiler-runtime", "react-dom/server"];
//# sourceMappingURL=astro.d.ts.map