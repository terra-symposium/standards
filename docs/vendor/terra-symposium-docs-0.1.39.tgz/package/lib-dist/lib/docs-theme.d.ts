import type { CSSProperties } from 'react';
/** Build both hue scales; CSS selects the active one for the host's theme. */
export declare function docsHueTheme(hue: number | null): CSSProperties;
//# sourceMappingURL=docs-theme.d.ts.map