import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { defineBlockObject, defineInlineObject, defineTextBlock, EditorProvider, PortableTextEditable, useEditor, useEditorSelector, } from '@portabletext/editor';
import { createElement, useEffect, useRef, useState } from 'react';
import { NodePlugin } from '@portabletext/editor/plugins';
import { DOCS_BLOCK_TYPES } from '../../blocks.js';
import { BlockContext } from './docs/BlockContext.js';
import { TERRA_CONTENT_PROSE_CLASS } from './terra-content.styles.js';
import { renderCallout } from './docs/_Callout.js';
import { renderCode } from './docs/_DocsCode.js';
import { renderImage } from './docs/_DocsImage.js';
import { Embed } from './docs/_Embed.js';
import { renderMathBlock } from './docs/_Math.js';
import { NodesBlock } from './docs/_Nodes.js';
import { Raw } from './docs/_Raw.js';
import { renderTable } from './docs/_Table.js';
import { renderSections } from './docs/_Tabs.js';
import { TsDocs } from './docs/_TsDocs.js';
import MathInline from './docs/_math_inline.js';
import { DocsHeading } from './docs/heading.js';
import { TerraToolbar } from './docs/TerraToolbar.js';
import { createDocsSchema, safeLink } from '../../../lib/schema.js';
import { ErrorBoundary } from '../ui.js';
const containerTypes = new Set(['accordion', 'callout', 'tabs']);
const rendererByType = {
    accordion: renderSections,
    callout: renderCallout,
    code: renderCode,
    docImage: renderImage,
    embed: ({ attributes, children, node }) => (_jsxs("div", { ...attributes, "data-docs-editor-block": "Embed", children: [_jsx(Embed, { block: node }), children] })),
    math: renderMathBlock,
    nodes: ({ attributes, children, node }) => (_jsxs("div", { ...attributes, "data-docs-editor-block": "Diagram", children: [_jsx(NodesBlock, { block: node }), children] })),
    raw: ({ attributes, children, node }) => (_jsxs("div", { ...attributes, "data-docs-editor-block": "Raw Markdown", children: [_jsx(Raw, { block: node }), children] })),
    table: renderTable,
    tabs: renderSections,
    tsDocs: ({ attributes, children, node }) => (_jsxs("div", { ...attributes, "data-docs-editor-block": "TypeScript docs", children: [_jsx(TsDocs, { block: node }), children] })),
};
function isMember(value) {
    return Boolean(value &&
        typeof value === 'object' &&
        !Array.isArray(value) &&
        typeof value._type === 'string');
}
function isPreservedMember(value) {
    return isMember(value) && typeof value._key === 'string';
}
function fallbackInline(value) {
    return {
        ...(value._key ? { _key: value._key } : {}),
        _type: 'todoInline',
        source: value,
    };
}
function normalizeTextChildren(value, options) {
    if (!Array.isArray(value))
        return [];
    return value.map((child) => {
        if (!isMember(child))
            return child;
        if (child._type === 'span' || child._type === 'todoInline')
            return child;
        if (child._type === 'math' && options.inlineMath !== false)
            return child;
        return fallbackInline(child);
    });
}
function normalizeNestedContent(value, options) {
    return Array.isArray(value) ? toEditorValue(value, options) : value;
}
/** Translate the stored Terra text-block alias into Portable Text's editor member. */
function toEditorValue(value, options = {}) {
    return value.filter(isMember).map((member) => {
        if (member._type === 'block' || member._type === 'terraBlock') {
            const { c, children, ...rest } = member;
            return {
                ...rest,
                _type: 'block',
                children: normalizeTextChildren(Array.isArray(children) && children.length > 0 ? children : c, options),
            };
        }
        if (member._type === 'todoBlock')
            return member;
        if (DOCS_BLOCK_TYPES.includes(member._type)) {
            if (options[member._type] === false)
                return {
                    _key: member._key,
                    _type: 'todoBlock',
                    source: member,
                };
            if (member._type === 'callout')
                return {
                    ...member,
                    content: normalizeNestedContent(member.content, options),
                };
            if (member._type === 'tabs' || member._type === 'accordion')
                return {
                    ...member,
                    items: Array.isArray(member.items)
                        ? member.items.map((item) => isMember(item)
                            ? { ...item, content: normalizeNestedContent(item.content, options) }
                            : item)
                        : member.items,
                };
            if (member._type === 'table')
                return {
                    ...member,
                    rows: Array.isArray(member.rows)
                        ? member.rows.map((row) => isMember(row)
                            ? {
                                ...row,
                                cells: Array.isArray(row.cells)
                                    ? row.cells.map((cell) => isMember(cell)
                                        ? {
                                            ...cell,
                                            content: normalizeNestedContent(cell.content, options),
                                        }
                                        : cell)
                                    : row.cells,
                            }
                            : row)
                        : member.rows,
                };
            return member;
        }
        return {
            _key: member._key,
            _type: 'todoBlock',
            source: member,
        };
    });
}
function restoreTextChildren(value) {
    if (!Array.isArray(value))
        return value;
    return value.map((child) => {
        if (!isMember(child))
            return child;
        if (child._type === 'todoInline' && isPreservedMember(child.source))
            return child.source;
        return child;
    });
}
/** Restore editor aliases and recursively preserve nested Portable Text source. */
function toTerraValue(value) {
    return value.map((block) => {
        const member = block;
        if (member._type === 'block')
            return {
                ...member,
                _type: 'terraBlock',
                children: restoreTextChildren(member.children),
            };
        if (member._type === 'todoBlock' && isPreservedMember(member.source))
            return member.source;
        if (member._type === 'callout')
            return {
                ...member,
                content: Array.isArray(member.content)
                    ? toTerraValue(member.content)
                    : member.content,
            };
        if (member._type === 'tabs' || member._type === 'accordion')
            return {
                ...member,
                items: Array.isArray(member.items)
                    ? member.items.map((item) => isMember(item)
                        ? {
                            ...item,
                            content: Array.isArray(item.content)
                                ? toTerraValue(item.content)
                                : item.content,
                        }
                        : item)
                    : member.items,
            };
        if (member._type === 'table')
            return {
                ...member,
                rows: Array.isArray(member.rows)
                    ? member.rows.map((row) => isMember(row)
                        ? {
                            ...row,
                            cells: Array.isArray(row.cells)
                                ? row.cells.map((cell) => isMember(cell)
                                    ? {
                                        ...cell,
                                        content: Array.isArray(cell.content)
                                            ? toTerraValue(cell.content)
                                            : cell.content,
                                    }
                                    : cell)
                                : row.cells,
                        }
                        : row)
                    : member.rows,
            };
        return member;
    });
}
function renderTextStyle(style, children, readOnly) {
    if (style === 'blockquote')
        return _jsx("blockquote", { children: children });
    if (typeof style === 'string' && /^h[2-6]$/.test(style) && readOnly)
        return _jsx(DocsHeading, { level: style, children: children });
    if (typeof style === 'string' && /^h[1-6]$/.test(style))
        return createElement(style, {}, children);
    return _jsx("p", { children: children });
}
function TerraTextBlock({ attributes, children, node, readOnly }) {
    const content = renderTextStyle(node.style, children, readOnly);
    if (!node.listItem)
        return (_jsx("div", { ...attributes, "data-level": node.level, "data-style": node.style, children: content }));
    const item = (_jsx("li", { "data-level": node.level ?? 1, "data-list-item": node.listItem, children: content }));
    return (_jsx("div", { ...attributes, "data-level": node.level ?? 1, "data-list-item": node.listItem, children: node.listItem === 'number' ? (_jsx("ol", { className: "list-decimal", children: item })) : (_jsx("ul", { className: "list-disc", children: item })) }));
}
function UnsupportedBlock({ attributes, children, node }) {
    const source = isPreservedMember(node.source) ? node.source : node;
    return (_jsxs("div", { ...attributes, contentEditable: false, "data-docs-unsupported-block": source._type, children: [_jsxs("p", { className: "text-sm text-primary-10", children: ["Unsupported document block (", source._type, ") retained in source."] }), _jsx("pre", { className: "max-h-48 overflow-auto whitespace-pre-wrap rounded border border-primary-5 p-3 text-xs", children: JSON.stringify(source, null, 2) }), children] }));
}
function UnsupportedInline({ attributes, children, node }) {
    const source = isPreservedMember(node.source) ? node.source : node;
    return (_jsxs("span", { ...attributes, contentEditable: false, "data-docs-unsupported-inline": source._type, children: [source.text ?? `[Unsupported ${source._type}]`, children] }));
}
function ContentChangeListener({ onChange }) {
    const value = useEditorSelector(useEditor(), (snapshot) => snapshot.context.value);
    const previous = useRef(value);
    useEffect(() => {
        if (previous.current === value)
            return;
        previous.current = value;
        onChange(toTerraValue(value));
    }, [onChange, value]);
    return null;
}
function validateNesting(value, depth = 0) {
    if (Array.isArray(value)) {
        for (const item of value) {
            const result = validateNesting(item, depth);
            if (result !== true)
                return result;
        }
    }
    else if (value && typeof value === 'object') {
        const member = value;
        const nextDepth = depth + (typeof member._type === 'string' && containerTypes.has(member._type) ? 1 : 0);
        if (nextDepth > 1)
            return 'Tabs, accordions, and callouts cannot be nested inside another tabs, accordion, or callout block.';
        for (const child of Object.values(member)) {
            const result = validateNesting(child, nextDepth);
            if (result !== true)
                return result;
        }
    }
    return true;
}
/** Portable Docs editor profile extracted from Terra's shared content editor. */
export function TerraContentEditor({ content = [], onChange, readOnly = false, resetKey, nested = false, docsAttachments = [], toolbarActions, blocks = {}, }) {
    const [nestingError, setNestingError] = useState(undefined);
    const [rejectedChanges, setRejectedChanges] = useState(0);
    const updateContent = (value) => {
        const result = validateNesting(value, nested ? 1 : 0);
        if (result !== true) {
            setNestingError(result);
            setRejectedChanges((count) => count + 1);
            return;
        }
        setNestingError(undefined);
        onChange?.(value);
    };
    const nodes = [
        defineTextBlock({
            type: 'block',
            render: (props) => _jsx(TerraTextBlock, { ...props }),
        }),
        ...Object.entries(rendererByType)
            .filter(([type]) => blocks[type] !== false)
            .map(([type, render]) => defineBlockObject({ type, render: (props) => render(props) ?? _jsx(_Fragment, {}) })),
        ...(blocks.inlineMath === false
            ? []
            : [defineInlineObject({ type: 'math', render: (props) => _jsx(MathInline, { ...props }) })]),
        defineBlockObject({ type: 'todoBlock', render: (props) => _jsx(UnsupportedBlock, { ...props }) }),
        defineInlineObject({ type: 'todoInline', render: (props) => _jsx(UnsupportedInline, { ...props }) }),
    ];
    return (_jsx(ErrorBoundary, { name: "TerraContent", children: _jsxs(EditorProvider, { initialConfig: {
                initialValue: toEditorValue(content, blocks),
                readOnly,
                schemaDefinition: createDocsSchema(blocks),
            }, children: [_jsx(NodePlugin, { nodes: nodes }), !readOnly && _jsx(ContentChangeListener, { onChange: updateContent }), !readOnly && (_jsx("div", { className: "not-prose sticky top-3 z-20 mb-3", children: _jsx(TerraToolbar, { nested: nested, actions: toolbarActions, attachments: docsAttachments, blocks: blocks, onChange: (value) => updateContent(toTerraValue(value)) }) })), nestingError && _jsx("p", { role: "alert", children: nestingError }), _jsx(BlockContext, { enabled: !readOnly, children: _jsx("section", { "aria-label": readOnly ? 'Terra content preview' : 'Terra content editor', className: "bg-transparent", "data-terra-content-editor": true, children: _jsx("div", { className: nested ? (readOnly ? '' : 'my-4 min-h-24') : 'my-6 min-h-96', children: _jsx(PortableTextEditable, { "aria-label": readOnly ? 'Document viewer' : 'Document editor', "aria-readonly": readOnly || undefined, className: `terra-docs-content ${TERRA_CONTENT_PROSE_CLASS} outline-none`, contentEditable: !readOnly, renderListItem: ({ children, level, value }) => {
                                    const item = (_jsx("li", { "data-level": level, "data-list-item": value, children: children }));
                                    return value === 'number' ? (_jsx("ol", { className: "list-decimal", children: item })) : (_jsx("ul", { className: "list-disc", children: item }));
                                }, renderAnnotation: ({ children, value }) => {
                                    const href = safeLink(value.href);
                                    return href ? _jsx("a", { href: href, children: children }) : _jsx(_Fragment, { children: children });
                                }, renderBlock: ({ children }) => _jsx(_Fragment, { children: children }), renderDecorator: ({ children, value }) => {
                                    if (value === 'strong')
                                        return _jsx("strong", { children: children });
                                    if (value === 'em')
                                        return _jsx("em", { children: children });
                                    if (value === 'underline')
                                        return _jsx("u", { children: children });
                                    if (value === 'strike-through')
                                        return _jsx("s", { children: children });
                                    if (value === 'code')
                                        return _jsx("code", { children: children });
                                    return _jsx(_Fragment, { children: children });
                                }, renderStyle: ({ children, schemaType }) => renderTextStyle(schemaType.value, children, readOnly) }) }) }) })] }, `${resetKey ?? ''}:${rejectedChanges}`) }));
}
//# sourceMappingURL=TerraContentEditor.js.map