import type { DocsBlockOptions } from './blocks.js';
import type { DocsHostAttachment, DocsHostTreeNode, DocsCustomBlock } from '../lib/host.js';
import type { JSX, ReactNode } from 'react';
/** A local page supplied by a repository or static site build. */
export type DocsLocalPage = {
    id: string;
    path: string;
    pathname: string;
    title: string;
    markdown: string;
    description?: string;
    contributors?: string[];
    updatedAt?: string;
    attachments?: DocsHostAttachment[];
};
export type DocsLocalWorkspaceProps = {
    tree: DocsHostTreeNode[];
    pages: DocsLocalPage[];
    pathname: string;
    title: string;
    description?: string;
    hue?: number | null;
    rootPath?: string;
    homePath?: string;
    afterContent?: ReactNode;
    customBlocks?: DocsCustomBlock[];
    blocks?: DocsBlockOptions;
};
export declare function findDocsLocalPage(pages: DocsLocalPage[], value: unknown): DocsLocalPage | undefined;
/**
 * Render repository-owned Markdown with the original Terra Docs workspace.
 * This adapter has no write operations, account dependency, or server requirement.
 */
export declare function DocsLocalWorkspace(props: DocsLocalWorkspaceProps): JSX.Element;
//# sourceMappingURL=LocalDocsWorkspace.d.ts.map