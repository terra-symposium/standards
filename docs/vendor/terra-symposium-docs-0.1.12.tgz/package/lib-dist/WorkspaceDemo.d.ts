import type { JSX } from 'react';
export default function WorkspaceDemo({ readOnly }?: {
    readOnly?: boolean;
}): JSX.Element;
//# sourceMappingURL=WorkspaceDemo.d.ts.map