import type { JSX } from 'react';
declare global {
    interface Window {
        __terraContentFixture?: unknown[];
        __terraContentOptions?: {
            readOnly?: boolean;
        };
        __terraDocsMockResponses?: Record<string, {
            data?: unknown;
            dataByInput?: Record<string, unknown>;
            error?: string;
        }>;
    }
}
export default function EditorHarness(): JSX.Element;
//# sourceMappingURL=EditorHarness.d.ts.map