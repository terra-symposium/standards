import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { TerraContentEditor } from './terra/editor/TerraContentEditor.js';
import { configureDocsHost } from './host-runtime.js';
function mapContent(value) {
    if (Array.isArray(value))
        return value.map(mapContent);
    if (!value || typeof value !== 'object')
        return value;
    const node = value;
    const type = node._type === 'terraBlock' ? 'block' : node._type;
    return Object.fromEntries(Object.entries(node).map(([key, entry]) => [key, key === '_type' ? type : mapContent(entry)]));
}
const host = {
    capabilities: { read: true, write: true, attachments: true, reorder: true, export: true, history: true, publish: true },
    async invoke(operation, input) {
        const mock = typeof window === 'undefined' ? undefined : window.__terraDocsMockResponses?.[operation];
        if (mock?.error)
            return { error: new Error(mock.error) };
        const inputKey = input && typeof input === 'object' && 'source' in input ? String(input.source) : '';
        const data = inputKey ? (mock?.dataByInput?.[inputKey] ?? mock?.data) : mock?.data;
        return { data: mapContent(data) };
    },
};
export default function EditorHarness() {
    configureDocsHost(host);
    const [readOnly] = useState(() => (typeof window === 'undefined' ? false : window.__terraContentOptions?.readOnly ?? false));
    const [content, setContent] = useState(() => mapContent(typeof window === 'undefined' ? [] : (window.__terraContentFixture ?? [])) ?? []);
    return (_jsxs("main", { className: "terra-docs-workspace mx-auto min-h-svh max-w-5xl p-6", children: [_jsx(TerraContentEditor, { content: content, readOnly: readOnly, onChange: value => setContent(value) }), _jsx("pre", { "data-testid": "editor-output", className: "sr-only", children: JSON.stringify(content) })] }));
}
//# sourceMappingURL=EditorHarness.js.map