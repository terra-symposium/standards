import { jsx as _jsx } from "react/jsx-runtime";
import { Component } from 'react';
export { Empty } from '@terra-symposium/styling/ui/terra-original';
export class ErrorBoundary extends Component {
    state = { error: null };
    static getDerivedStateFromError(error) {
        return { error };
    }
    componentDidCatch(_error, _info) { }
    render() {
        return this.state.error
            ? (this.props.fallback?.(this.state.error) ?? (_jsx("div", { role: "alert", children: this.state.error.message })))
            : this.props.children;
    }
}
export const IMG_RESPONSIVE = 'max-w-full object-contain';
export default function User({ user, }) {
    return _jsx("span", { className: "text-sm text-primary-11", children: user?.name ?? user?.email ?? '' });
}
//# sourceMappingURL=ui.js.map