import type { DocsNavNode } from './navigation.js';
import type { JSX, ReactNode } from 'react';
/** Shared Terra Docs page shell for independent installations and repository guides. */
export declare function DocsSiteLayout({ title, homeHref, description, pageTitle, nodes, currentPath, hue, children, sidebarContent, }: {
    title: string;
    homeHref?: string;
    description?: string;
    pageTitle?: string;
    nodes: DocsNavNode[];
    currentPath: string;
    hue?: number | null;
    children: ReactNode;
    sidebarContent?: ReactNode;
}): JSX.Element;
//# sourceMappingURL=SiteLayout.d.ts.map