import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { colors } from '@terra-symposium/styling';
import { DocsNavigation } from './navigation.js';
/** Shared Terra Docs page shell for independent installations and repository guides. */
export function DocsSiteLayout({ title, homeHref = '/', description, pageTitle, nodes, currentPath, hue = 145, children, sidebarContent, }) {
    const [accent] = colors(hue);
    const style = { '--terra-docs-accent': `rgb(${accent.light[8]})` };
    return (_jsxs("div", { className: "terra-docs-site", style: style, children: [_jsxs("header", { className: "terra-docs-site-header", children: [_jsx("a", { className: "terra-docs-site-brand", href: homeHref, children: title }), description && _jsx("span", { className: "terra-docs-site-description", children: description })] }), _jsxs("div", { className: "terra-docs-site-layout", children: [_jsxs("aside", { className: "terra-docs-site-sidebar", children: [_jsx(DocsNavigation, { nodes: nodes, currentPath: currentPath, hue: hue }), sidebarContent] }), _jsx("main", { className: "terra-docs-site-main", children: _jsxs("article", { className: "terra-docs-site-article", children: [pageTitle && _jsx("h1", { className: "terra-docs-site-page-title", children: pageTitle }), children] }) })] })] }));
}
//# sourceMappingURL=SiteLayout.js.map