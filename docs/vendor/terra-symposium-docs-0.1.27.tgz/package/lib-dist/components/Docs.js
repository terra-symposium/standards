import { jsx as _jsx } from "react/jsx-runtime";
import { TerraContentEditor } from './terra/editor/TerraContentEditor.js';
/** Controlled editor surface backed by the canonical Terra Docs editor. */
export function Docs(props) {
    return (_jsx("div", { className: ['terra-docs', props.className].filter(Boolean).join(' '), children: _jsx(TerraContentEditor, { content: props.value, readOnly: props.mode === 'view', ...(props.blocks !== undefined ? { blocks: props.blocks } : {}), ...(props.mode === 'edit'
                ? { onChange: (value) => props.onChange(value) }
                : {}) }) }));
}
//# sourceMappingURL=Docs.js.map