import type { JSX, ReactNode } from 'react';
/** Preserve the original Docs block context menu and its deferred focus handoff. */
export declare function BlockContext({ children, enabled, }: {
    children: ReactNode;
    enabled?: boolean;
}): JSX.Element;
//# sourceMappingURL=BlockContext.d.ts.map