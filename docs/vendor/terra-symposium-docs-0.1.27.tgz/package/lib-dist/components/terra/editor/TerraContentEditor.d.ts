import type { JSX, ReactNode } from 'react';
import type { DocsBlockOptions } from '../../blocks.js';
import type { DocsHostAttachment } from '../../../lib/host.js';
/** Portable Docs editor profile extracted from Terra's shared content editor. */
export declare function TerraContentEditor({ content, onChange, readOnly, resetKey, nested, docsAttachments, toolbarActions, blocks, }: {
    content?: unknown[];
    onChange?: (content: unknown[]) => void;
    readOnly?: boolean;
    resetKey?: string;
    nested?: boolean;
    docsAttachments?: DocsHostAttachment[];
    toolbarActions?: ReactNode;
    blocks?: DocsBlockOptions;
}): JSX.Element;
//# sourceMappingURL=TerraContentEditor.d.ts.map