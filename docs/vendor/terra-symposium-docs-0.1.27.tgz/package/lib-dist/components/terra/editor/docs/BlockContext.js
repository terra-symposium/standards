import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useRef, useState } from 'react';
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuSeparator, ContextMenuSub, ContextMenuSubContent, ContextMenuSubTrigger, ContextMenuTrigger, } from '@terra-symposium/styling/ui/terra-original';
import { ErrorBoundary } from '../../ui.js';
/** Preserve the original Docs block context menu and its deferred focus handoff. */
export function BlockContext({ children, enabled = true, }) {
    const [actions, setActions] = useState(null);
    const selectedAction = useRef([]);
    if (!enabled)
        return _jsx(_Fragment, { children: children });
    return (_jsx(ErrorBoundary, { name: "BlockContext", children: _jsxs(ContextMenu, { onOpenChange: (open) => !open && setActions(null), children: [_jsx(ContextMenuTrigger, { asChild: true, children: _jsx("div", { className: "docs-context-menu-trigger-wrapper", children: _jsx("div", { className: "relative w-full", onContextMenuCapture: (event) => {
                                let current = event.target instanceof HTMLElement
                                    ? event.target
                                    : event.target instanceof Node
                                        ? event.target.parentElement
                                        : null;
                                const nextActions = [];
                                while (current && current !== event.currentTarget) {
                                    if (current.__blockActions?.length) {
                                        if (nextActions.length)
                                            nextActions.push({ sep: true });
                                        nextActions.push(...current.__blockActions);
                                    }
                                    current = current.parentElement;
                                }
                                if (!nextActions.length) {
                                    const block = event.target.closest('[data-docs-editor-block], [data-docs-block], [data-terra-block]');
                                    if (!block) {
                                        event.stopPropagation();
                                        return;
                                    }
                                    nextActions.push({
                                        text: 'Select block',
                                        onSelect: () => document.dispatchEvent(new CustomEvent('docs:block-select', {
                                            detail: {
                                                block,
                                                decorator: block.closest('.docs-context-wrapper') || block,
                                            },
                                        })),
                                    });
                                }
                                setActions(nextActions);
                            }, children: children }) }) }), _jsx(ContextMenuContent, { className: "w-64", onCloseAutoFocus: (event) => {
                        if (!selectedAction.current.length)
                            return;
                        event.preventDefault();
                        selectedAction.current.splice(0, 1)[0]?.();
                    }, children: actions?.map((action, index) => {
                        if ('sep' in action)
                            return _jsx(ContextMenuSeparator, {}, `separator-${index}`);
                        if ('sub' in action)
                            return (_jsxs(ContextMenuSub, { children: [_jsxs(ContextMenuSubTrigger, { children: [action.icon, " ", action.text] }), _jsx(ContextMenuSubContent, { children: action.sub.map((item) => (_jsxs(ContextMenuItem, { intent: item.intent, onSelect: () => {
                                                selectedAction.current[0] = item.onSelect ?? null;
                                            }, children: [item.icon, " ", item.text] }, item.text))) })] }, action.text));
                        return (_jsxs(ContextMenuItem, { intent: action.intent, onSelect: () => {
                                selectedAction.current.splice(0, 1, action.onSelect ?? null);
                            }, children: [action.icon, " ", action.text] }, action.text));
                    }) })] }) }));
}
//# sourceMappingURL=BlockContext.js.map