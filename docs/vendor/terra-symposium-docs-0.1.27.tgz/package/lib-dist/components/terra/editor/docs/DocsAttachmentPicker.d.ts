import type { DocsBlockOptions } from '../../../blocks.js';
import type { DocsHostAttachment } from '../../../../lib/host.js';
import type { JSX } from 'react';
/** Select an attachment belonging to the current leaf and insert it in the document body. */
export declare function DocsAttachmentPicker({ attachments, blocks, onConfirm, onOpenChange, open, }: {
    attachments: DocsHostAttachment[];
    blocks?: DocsBlockOptions;
    onConfirm: (member: Record<string, unknown>) => void;
    onOpenChange: (open: boolean) => void;
    open: boolean;
}): JSX.Element;
//# sourceMappingURL=DocsAttachmentPicker.d.ts.map