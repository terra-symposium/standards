import type { DocsBlockOptions } from '../../../blocks.js';
import type { DocsHostAttachment } from '../../../../lib/host.js';
import type { JSX, ReactNode } from 'react';
/** Formatting and insertion controls mechanically adapted from Terra's original Docs toolbar. */
export declare function TerraToolbar({ actions, attachments, blocks, onChange, nested, }: {
    actions?: ReactNode;
    attachments: DocsHostAttachment[];
    blocks?: DocsBlockOptions;
    onChange: (content: unknown[]) => void;
    nested?: boolean;
}): JSX.Element;
//# sourceMappingURL=TerraToolbar.d.ts.map