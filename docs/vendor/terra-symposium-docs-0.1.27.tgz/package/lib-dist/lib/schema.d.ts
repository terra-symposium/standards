import type { DocsBlockOptions } from '../components/blocks.js';
/** Basic text schema shared by the document surface and Terra formatting toolbar. */
export declare function createDocsSchema(options?: DocsBlockOptions): {
    readonly styles: readonly [{
        readonly name: "normal";
        readonly title: "Normal";
    }, {
        readonly name: "h2";
        readonly title: "Heading 2";
    }, {
        readonly name: "h3";
        readonly title: "Heading 3";
    }, {
        readonly name: "h4";
        readonly title: "Heading 4";
    }, {
        readonly name: "h5";
        readonly title: "Heading 5";
    }, {
        readonly name: "h6";
        readonly title: "Heading 6";
    }, {
        readonly name: "blockquote";
        readonly title: "Quote";
    }];
    readonly decorators: readonly [{
        readonly name: "strong";
        readonly title: "Bold";
    }, {
        readonly name: "em";
        readonly title: "Italic";
    }, {
        readonly name: "underline";
        readonly title: "Underline";
    }, {
        readonly name: "strike-through";
        readonly title: "Strikethrough";
    }, {
        readonly name: "code";
        readonly title: "Code";
    }];
    readonly annotations: readonly [{
        readonly name: "link";
        readonly fields: readonly [{
            readonly name: "href";
            readonly type: "string";
        }];
    }];
    readonly lists: readonly [{
        readonly name: "bullet";
    }, {
        readonly name: "number";
    }];
    readonly blockObjects: readonly [...{
        name: "accordion" | "tabs" | "table" | "callout" | "code" | "docImage" | "embed" | "math" | "nodes" | "raw" | "tsDocs";
        fields: {
            name: string;
            type: "string" | "number" | "boolean" | "array" | "object";
        }[];
    }[], {
        readonly name: "todoBlock";
        readonly fields: readonly [{
            readonly name: "source";
            readonly type: "object";
        }];
    }];
    readonly inlineObjects: readonly [...{
        name: string;
        fields: ({
            name: string;
            type: "string";
        } | {
            name: string;
            type: "boolean";
        })[];
    }[], {
        readonly name: "todoInline";
        readonly fields: readonly [{
            readonly name: "source";
            readonly type: "object";
        }];
    }];
};
export declare const schema: {
    readonly styles: readonly [{
        readonly name: "normal";
        readonly title: "Normal";
    }, {
        readonly name: "h2";
        readonly title: "Heading 2";
    }, {
        readonly name: "h3";
        readonly title: "Heading 3";
    }, {
        readonly name: "h4";
        readonly title: "Heading 4";
    }, {
        readonly name: "h5";
        readonly title: "Heading 5";
    }, {
        readonly name: "h6";
        readonly title: "Heading 6";
    }, {
        readonly name: "blockquote";
        readonly title: "Quote";
    }];
    readonly decorators: readonly [{
        readonly name: "strong";
        readonly title: "Bold";
    }, {
        readonly name: "em";
        readonly title: "Italic";
    }, {
        readonly name: "underline";
        readonly title: "Underline";
    }, {
        readonly name: "strike-through";
        readonly title: "Strikethrough";
    }, {
        readonly name: "code";
        readonly title: "Code";
    }];
    readonly annotations: readonly [{
        readonly name: "link";
        readonly fields: readonly [{
            readonly name: "href";
            readonly type: "string";
        }];
    }];
    readonly lists: readonly [{
        readonly name: "bullet";
    }, {
        readonly name: "number";
    }];
    readonly blockObjects: readonly [...{
        name: "accordion" | "tabs" | "table" | "callout" | "code" | "docImage" | "embed" | "math" | "nodes" | "raw" | "tsDocs";
        fields: {
            name: string;
            type: "string" | "number" | "boolean" | "array" | "object";
        }[];
    }[], {
        readonly name: "todoBlock";
        readonly fields: readonly [{
            readonly name: "source";
            readonly type: "object";
        }];
    }];
    readonly inlineObjects: readonly [...{
        name: string;
        fields: ({
            name: string;
            type: "string";
        } | {
            name: string;
            type: "boolean";
        })[];
    }[], {
        readonly name: "todoInline";
        readonly fields: readonly [{
            readonly name: "source";
            readonly type: "object";
        }];
    }];
};
/** Accepts web and email links, including relative links, without executable URL schemes. */
export declare function safeLink(value: unknown): string | undefined;
//# sourceMappingURL=schema.d.ts.map