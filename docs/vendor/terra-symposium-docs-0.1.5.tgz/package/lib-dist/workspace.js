import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
function firstLeaf(section) {
    return section.groups.flatMap((group) => group.leaves)[0]?.href ?? '/';
}
function sectionForPath(sections, path) {
    return Math.max(0, sections.findIndex((section) => section.groups.some((group) => group.leaves.some((leaf) => leaf.href === path))));
}
export function DocsWorkspaceNavigation({ sections, currentPath, }) {
    const [sectionIndex, setSectionIndex] = useState(() => sectionForPath(sections, currentPath));
    useEffect(() => setSectionIndex(sectionForPath(sections, currentPath)), [sections, currentPath]);
    const section = sections[sectionIndex];
    const groups = section?.groups ?? [];
    return (_jsxs("nav", { className: "terra-docs-workspace-nav", "aria-label": "Documentation", children: [_jsx("label", { className: "terra-docs-control-label", htmlFor: "terra-docs-section", children: "Section" }), _jsx("select", { id: "terra-docs-section", "aria-label": "Section", value: sectionIndex, onChange: (event) => {
                    const index = Number(event.currentTarget.value);
                    setSectionIndex(index);
                    const href = sections[index] && firstLeaf(sections[index]);
                    if (href)
                        window.location.assign(href);
                }, children: sections.map((entry, index) => (_jsx("option", { value: index, children: entry.title }, `${entry.title}-${index}`))) }), _jsx("div", { className: "terra-docs-workspace-groups", children: groups.map((group, index) => (_jsxs("div", { className: "terra-docs-workspace-group", children: [_jsx("h2", { children: group.title }), _jsx("ul", { children: group.leaves.map((leaf, leafIndex) => (_jsxs("li", { onContextMenu: (event) => {
                                    event.preventDefault();
                                    const menu = event.currentTarget.querySelector('details');
                                    if (menu)
                                        menu.open = true;
                                }, children: [_jsx("a", { href: leaf.href, "aria-current": leaf.href === currentPath ? 'page' : undefined, children: leaf.title }), _jsxs("details", { className: "terra-docs-leaf-menu", children: [_jsx("summary", { "aria-label": `Actions for ${leaf.title}`, children: "\u22EF" }), _jsxs("div", { role: "group", "aria-label": `Actions for ${leaf.title}`, children: [_jsx("a", { href: leaf.href, target: "_blank", rel: "noopener noreferrer", children: "Open in new tab" }), _jsx("button", { type: "button", onClick: () => {
                                                            void navigator.clipboard.writeText(new URL(leaf.href, window.location.href).href);
                                                        }, children: "Copy link" })] })] })] }, `${leaf.href}-${leafIndex}`))) })] }, `${group.title}-${index}`))) }), groups.length === 0 && _jsx("p", { className: "terra-docs-empty", children: "No pages in this section." })] }));
}
export function DocsWorkspaceToolbar({ capabilities = {}, onEdit, onSave, onHistory, onPublish, remoteProvider, onModeChange, }) {
    const [mode, setMode] = useState('view');
    useEffect(() => {
        const element = document.querySelector('.terra-docs-site');
        if (element)
            element.dataset.docsMode = mode;
        return () => {
            if (element)
                delete element.dataset.docsMode;
        };
    }, [mode]);
    return (_jsxs("div", { className: "terra-docs-workspace-toolbar", role: "toolbar", "aria-label": "Document controls", children: [_jsxs("select", { "aria-label": "Mode", value: mode, onChange: (event) => {
                    const next = event.currentTarget.value;
                    setMode(next);
                    onModeChange?.(next);
                    if (next === 'edit')
                        onEdit?.();
                }, children: [_jsx("option", { value: "view", children: "View" }), capabilities.edit && remoteProvider && _jsx("option", { value: "edit", children: "Edit" }), _jsx("option", { value: "attachments", children: "Attachments" })] }), mode === 'edit' && capabilities.save && (_jsx("button", { type: "button", onClick: onSave, children: "Save" })), mode === 'edit' && capabilities.history && (_jsx("button", { type: "button", onClick: onHistory, children: "History" })), mode === 'edit' && capabilities.publish && (_jsx("button", { type: "button", onClick: onPublish, children: "Publish" }))] }));
}
export function DocsAttachmentsView({ attachments = [], onUpload, }) {
    return (_jsxs("section", { className: "terra-docs-attachments-view", "aria-label": "Attachments", children: [_jsx("h2", { children: "Attachments" }), onUpload && (_jsxs("label", { className: "terra-docs-attachment-upload", children: ["Add attachment", ' ', _jsx("input", { type: "file", onChange: (event) => {
                            const file = event.currentTarget.files?.[0];
                            if (file)
                                void onUpload(file);
                            event.currentTarget.value = '';
                        } })] })), attachments.length ? (_jsx("ul", { children: attachments.map((attachment, index) => (_jsxs("li", { children: [_jsx("a", { href: attachment.href, target: "_blank", rel: "noopener noreferrer", children: attachment.title }), attachment.type && _jsx("span", { children: attachment.type })] }, `${attachment.href}-${index}`))) })) : (_jsx("p", { children: "No attachments found." }))] }));
}
//# sourceMappingURL=workspace.js.map