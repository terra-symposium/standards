/**
 * Vite dependencies that must be pre-bundled when an Astro React island loads
 * the published Docs package. The package is distributed as unbundled ESM,
 * while several editor dependencies (notably use-sync-external-store's shim)
 * still expose CommonJS entrypoints.
 */
export declare const DOCS_VITE_OPTIMIZE_DEPS: readonly ["@terra-symposium/docs/local-workspace", "@terra-symposium/docs > @dagrejs/dagre", "@terra-symposium/docs > sanitize-html", "debug", "react/compiler-runtime", "react-dom/server", "use-sync-external-store/shim", "use-sync-external-store/shim/with-selector", "use-sync-external-store/shim/with-selector.js"];
//# sourceMappingURL=astro.d.ts.map