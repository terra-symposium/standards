import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { defineBlockObject, defineInlineObject, useEditor } from '@portabletext/editor';
import { useState } from 'react';
import katex from 'katex';
import { renderMarkdown } from '../lib/markdown.js';
/** The portable Docs members. A host can disable any member without changing stored data. */
export const DOCS_BLOCK_TYPES = [
    'accordion',
    'tabs',
    'table',
    'callout',
    'code',
    'docImage',
    'embed',
    'math',
    'nodes',
    'raw',
    'tsDocs',
];
export function enabledDocsBlocks(options = {}) {
    return DOCS_BLOCK_TYPES.filter((type) => options[type] !== false);
}
export const DOCS_BLOCK_FIELDS = {
    accordion: [
        { name: 'items', type: 'array' },
        { name: 'markdown', type: 'string' },
    ],
    tabs: [
        { name: 'items', type: 'array' },
        { name: 'markdown', type: 'string' },
    ],
    table: [
        { name: 'header', type: 'string' },
        { name: 'rows', type: 'array' },
        { name: 'markdown', type: 'string' },
    ],
    callout: [
        { name: 'kind', type: 'string' },
        { name: 'title', type: 'string' },
        { name: 'content', type: 'array' },
        { name: 'markdown', type: 'string' },
    ],
    code: [
        { name: 'language', type: 'string' },
        { name: 'source', type: 'string' },
        { name: 'value', type: 'string' },
        { name: 'markdown', type: 'string' },
    ],
    docImage: [
        { name: 'alt', type: 'string' },
        { name: 'url', type: 'string' },
        { name: 'title', type: 'string' },
        { name: 'width', type: 'string' },
        { name: 'height', type: 'string' },
        { name: 'markdown', type: 'string' },
    ],
    embed: [
        { name: 'src', type: 'string' },
        { name: 'title', type: 'string' },
        { name: 'width', type: 'string' },
        { name: 'height', type: 'string' },
        { name: 'markdown', type: 'string' },
    ],
    math: [
        { name: 'code', type: 'string' },
        { name: 'inline', type: 'boolean' },
        { name: 'markdown', type: 'string' },
    ],
    nodes: [
        { name: 'nodes', type: 'array' },
        { name: 'edges', type: 'array' },
        { name: 'direction', type: 'string' },
        { name: 'height', type: 'number' },
        { name: 'nodeSep', type: 'number' },
        { name: 'rankSep', type: 'number' },
        { name: 'proximityConnect', type: 'boolean' },
        { name: 'markdown', type: 'string' },
    ],
    raw: [{ name: 'markdown', type: 'string' }],
    tsDocs: [
        { name: 'scope', type: 'string' },
        { name: 'markdown', type: 'string' },
    ],
};
const defaults = {
    accordion: { _type: 'accordion', items: [{ title: 'Item', content: [] }] },
    tabs: { _type: 'tabs', items: [{ title: 'Tab', content: [] }] },
    table: { _type: 'table', header: 'Table', rows: [] },
    callout: { _type: 'callout', kind: 'info', title: 'Note', content: [] },
    code: { _type: 'code', language: 'text', value: '' },
    docImage: { _type: 'docImage', alt: '', url: '' },
    embed: { _type: 'embed', src: '', title: '' },
    math: { _type: 'math', code: '', inline: false },
    nodes: { _type: 'nodes', nodes: [], edges: [], direction: 'TB' },
    raw: { _type: 'raw', markdown: '' },
    tsDocs: { _type: 'tsDocs', scope: '' },
};
export function defaultDocsBlock(type) {
    return structuredClone(defaults[type]);
}
function text(value) {
    if (typeof value === 'string')
        return value;
    if (Array.isArray(value))
        return value.map(text).join(' ');
    if (value && typeof value === 'object') {
        const item = value;
        return text(item.markdown ?? item.text ?? item.children ?? item.content ?? '');
    }
    return '';
}
function safeUrl(value) {
    if (typeof value !== 'string' || !value.trim())
        return undefined;
    try {
        const url = new URL(value, 'https://docs.invalid');
        return ['https:', 'http:', 'mailto:'].includes(url.protocol) ? value : undefined;
    }
    catch {
        return undefined;
    }
}
function nestedMarkdown(item) {
    return typeof item.markdown === 'string' ? item.markdown : text(item.content);
}
function Diagram({ block }) {
    const nodes = (Array.isArray(block.nodes) ? block.nodes : []).filter((node) => Boolean(node) && typeof node === 'object');
    const edges = (Array.isArray(block.edges) ? block.edges : []).filter((edge) => Boolean(edge) && typeof edge === 'object');
    const horizontal = block.direction === 'LR';
    const width = horizontal ? Math.max(320, nodes.length * 180) : 320;
    const height = horizontal ? 140 : Math.max(140, nodes.length * 100);
    const positions = new Map(nodes.map((node, index) => [
        String(node.id ?? index),
        horizontal ? { x: 90 + index * 180, y: 70 } : { x: 160, y: 70 + index * 100 },
    ]));
    return (_jsxs("figure", { className: "terra-docs-diagram", children: [_jsxs("svg", { role: "img", "aria-label": "Document diagram", viewBox: `0 0 ${width} ${height}`, children: [_jsx("defs", { children: _jsx("marker", { id: "terra-docs-arrow", markerWidth: "8", markerHeight: "8", refX: "7", refY: "4", orient: "auto", children: _jsx("path", { d: "M0 0 L8 4 L0 8 Z", fill: "currentColor" }) }) }), edges.map((edge, i) => {
                        const from = positions.get(String(edge.source ?? ''));
                        const to = positions.get(String(edge.target ?? ''));
                        return from && to ? (_jsx("line", { x1: from.x, y1: from.y, x2: to.x, y2: to.y, stroke: "currentColor", markerEnd: "url(#terra-docs-arrow)" }, i)) : null;
                    }), nodes.map((node, i) => {
                        const point = positions.get(String(node.id ?? i));
                        const data = node.data && typeof node.data === 'object'
                            ? node.data
                            : {};
                        return (_jsxs("g", { children: [_jsx("rect", { x: point.x - 75, y: point.y - 24, width: "150", height: "48", rx: "7", fill: "white", stroke: "currentColor" }), _jsx("text", { x: point.x, y: point.y + 5, textAnchor: "middle", children: text(data.title ?? node.id) })] }, i));
                    })] }), _jsxs("figcaption", { children: [nodes.length, " nodes, ", edges.length, " connections"] })] }));
}
/** Read-only rendering for every reusable Terra Docs member. Unknown data stays in the value. */
export function DocsRichBlock({ block }) {
    const items = Array.isArray(block.items) ? block.items : [];
    switch (block._type) {
        case 'accordion':
            return (_jsx("div", { className: "terra-docs-accordions", children: items.map((item, i) => (_jsxs("details", { children: [_jsx("summary", { children: text(item.title) }), _jsx("div", { dangerouslySetInnerHTML: { __html: renderMarkdown(nestedMarkdown(item)) } })] }, i))) }));
        case 'tabs':
            return (_jsx("div", { className: "terra-docs-tabs", role: "tablist", children: items.map((item, i) => (_jsxs("details", { open: i === 0, children: [_jsx("summary", { children: text(item.title) }), _jsx("div", { dangerouslySetInnerHTML: { __html: renderMarkdown(nestedMarkdown(item)) } })] }, i))) }));
        case 'table':
            return (_jsxs("section", { className: "terra-docs-table", children: [_jsx("strong", { children: text(block.header) }), _jsx("table", { children: _jsx("tbody", { children: (Array.isArray(block.rows) ? block.rows : []).map((row, i) => (_jsx("tr", { children: (Array.isArray(row.cells)
                                    ? row.cells
                                    : []).map((cell, j) => (_jsx("td", { children: text(cell) }, j))) }, i))) }) })] }));
        case 'callout':
            return (_jsxs("aside", { className: `terra-docs-callout terra-docs-callout-${text(block.kind).replace(/[^a-z0-9-]/gi, '') || 'info'}`, children: [_jsx("strong", { children: text(block.title) }), _jsx("div", { dangerouslySetInnerHTML: { __html: renderMarkdown(nestedMarkdown(block)) } })] }));
        case 'code':
            return (_jsx("pre", { className: "terra-docs-code", children: _jsx("code", { "data-language": text(block.language), children: text(block.value) }) }));
        case 'docImage':
            return safeUrl(block.url) ? (_jsxs("figure", { children: [_jsx("img", { src: safeUrl(block.url), alt: text(block.alt) }), _jsx("figcaption", { children: text(block.title) })] })) : (_jsx("p", { children: "Image URL unavailable" }));
        case 'embed':
            return safeUrl(block.src) ? (_jsx("iframe", { title: text(block.title) || 'Embedded content', src: safeUrl(block.src), loading: "lazy", sandbox: "allow-scripts allow-same-origin allow-popups" })) : (_jsx("p", { children: "Embed URL unavailable" }));
        case 'math': {
            const code = text(block.code);
            const html = katex.renderToString(code, {
                displayMode: !block.inline,
                throwOnError: false,
                strict: 'ignore',
                trust: false,
            });
            return block.inline ? (_jsx("span", { className: "terra-docs-math", "aria-label": code, dangerouslySetInnerHTML: { __html: html } })) : (_jsx("div", { className: "terra-docs-math", "aria-label": code, dangerouslySetInnerHTML: { __html: html } }));
        }
        case 'nodes':
            return _jsx(Diagram, { block: block });
        case 'raw':
            return (_jsx("div", { className: "terra-docs-raw", dangerouslySetInnerHTML: { __html: renderMarkdown(text(block.markdown)) } }));
        case 'tsDocs':
            return (_jsxs("section", { className: "terra-docs-tsdocs", children: [_jsxs("strong", { children: ["TypeScript: ", text(block.scope)] }), block.markdown && _jsx("p", { children: text(block.markdown) })] }));
        default:
            return (_jsx("pre", { "data-unsupported-block": block._type, children: block.markdown ?? JSON.stringify(block) }));
    }
}
function BlockEditor({ block, path, readOnly, }) {
    const editor = useEditor();
    const [expanded, setExpanded] = useState(false);
    const type = block._type;
    const fields = DOCS_BLOCK_FIELDS[type] ?? [];
    const set = (props) => editor.send({ type: 'block.set', at: path, props });
    const items = Array.isArray(block.items) ? block.items : [];
    const rows = Array.isArray(block.rows) ? block.rows : [];
    const nodes = Array.isArray(block.nodes) ? block.nodes : [];
    const edges = Array.isArray(block.edges) ? block.edges : [];
    return (_jsxs("div", { className: "terra-docs-rich-editor", children: [_jsx(DocsRichBlock, { block: block }), !readOnly && (_jsxs(_Fragment, { children: [_jsxs("button", { onClick: () => setExpanded(!expanded), "aria-expanded": expanded, children: ["Edit ", type] }), expanded && (_jsx("div", { className: "terra-docs-rich-fields", children: fields.map((field) => {
                            const value = block[field.name];
                            const update = (next) => set({ [field.name]: next, markdown: field.name === 'markdown' ? next : '' });
                            if (field.name === 'items')
                                return (_jsxs("fieldset", { children: [_jsx("legend", { children: "Items" }), items.map((item, index) => (_jsxs("div", { className: "terra-docs-rich-item", children: [_jsxs("label", { children: ["Title", _jsx("input", { value: text(item.title), onChange: (event) => set({
                                                                items: items.map((entry, i) => i === index
                                                                    ? { ...entry, title: event.currentTarget.value }
                                                                    : entry),
                                                                markdown: '',
                                                            }) })] }), _jsxs("label", { children: ["Content", _jsx("textarea", { value: nestedMarkdown(item), onChange: (event) => set({
                                                                items: items.map((entry, i) => i === index
                                                                    ? { ...entry, markdown: event.currentTarget.value }
                                                                    : entry),
                                                                markdown: '',
                                                            }) })] }), _jsx("button", { onClick: () => set({ items: items.filter((_entry, i) => i !== index), markdown: '' }), children: "Remove item" })] }, index))), _jsx("button", { onClick: () => set({
                                                items: [...items, { title: 'Item', markdown: '', content: [] }],
                                                markdown: '',
                                            }), children: "Add item" })] }, "items"));
                            if (field.name === 'rows')
                                return (_jsxs("fieldset", { children: [_jsx("legend", { children: "Table rows" }), rows.map((row, rowIndex) => {
                                            const cells = Array.isArray(row.cells)
                                                ? row.cells
                                                : [];
                                            return (_jsxs("div", { className: "terra-docs-rich-item", children: [cells.map((cell, cellIndex) => (_jsxs("label", { children: ["Cell ", cellIndex + 1, _jsx("input", { value: text(cell.content ?? cell.markdown), onChange: (event) => set({
                                                                    rows: rows.map((entry, i) => i === rowIndex
                                                                        ? {
                                                                            ...entry,
                                                                            cells: cells.map((current, j) => j === cellIndex
                                                                                ? {
                                                                                    ...current,
                                                                                    markdown: event.currentTarget.value,
                                                                                    content: [],
                                                                                }
                                                                                : current),
                                                                        }
                                                                        : entry),
                                                                    markdown: '',
                                                                }) })] }, cellIndex))), _jsx("button", { onClick: () => set({
                                                            rows: rows.map((entry, i) => i === rowIndex
                                                                ? {
                                                                    ...entry,
                                                                    cells: [
                                                                        ...cells,
                                                                        { _type: 'cell', content: [], markdown: '' },
                                                                    ],
                                                                }
                                                                : entry),
                                                            markdown: '',
                                                        }), children: "Add cell" }), _jsx("button", { onClick: () => set({
                                                            rows: rows.filter((_entry, i) => i !== rowIndex),
                                                            markdown: '',
                                                        }), children: "Remove row" })] }, rowIndex));
                                        }), _jsx("button", { onClick: () => set({
                                                rows: [
                                                    ...rows,
                                                    {
                                                        _type: 'row',
                                                        cells: [{ _type: 'cell', content: [], markdown: '' }],
                                                    },
                                                ],
                                                markdown: '',
                                            }), children: "Add row" })] }, "rows"));
                            if (field.name === 'nodes')
                                return (_jsxs("fieldset", { children: [_jsx("legend", { children: "Diagram nodes" }), nodes.map((node, index) => (_jsxs("div", { className: "terra-docs-rich-item", children: [_jsxs("label", { children: ["ID", _jsx("input", { value: text(node.id), onChange: (event) => set({
                                                                nodes: nodes.map((entry, i) => i === index
                                                                    ? { ...entry, id: event.currentTarget.value }
                                                                    : entry),
                                                                markdown: '',
                                                            }) })] }), _jsxs("label", { children: ["Title", _jsx("input", { value: text(node.data?.title), onChange: (event) => set({
                                                                nodes: nodes.map((entry, i) => i === index
                                                                    ? {
                                                                        ...entry,
                                                                        data: {
                                                                            ...(entry.data ?? {}),
                                                                            title: event.currentTarget.value,
                                                                        },
                                                                    }
                                                                    : entry),
                                                                markdown: '',
                                                            }) })] }), _jsx("button", { onClick: () => set({ nodes: nodes.filter((_entry, i) => i !== index), markdown: '' }), children: "Remove node" })] }, index))), _jsx("button", { onClick: () => set({
                                                nodes: [
                                                    ...nodes,
                                                    { id: crypto.randomUUID(), type: 'process', data: { title: 'Node' } },
                                                ],
                                                markdown: '',
                                            }), children: "Add node" })] }, "nodes"));
                            if (field.name === 'edges')
                                return (_jsxs("fieldset", { children: [_jsx("legend", { children: "Connections" }), edges.map((edge, index) => (_jsxs("div", { className: "terra-docs-rich-item", children: [['source', 'target'].map((name) => (_jsxs("label", { children: [name, _jsx("select", { value: text(edge[name]), onChange: (event) => set({
                                                                edges: edges.map((entry, i) => i === index
                                                                    ? { ...entry, [name]: event.currentTarget.value }
                                                                    : entry),
                                                                markdown: '',
                                                            }), children: nodes.map((node) => (_jsx("option", { value: text(node.id), children: text(node.data?.title ??
                                                                    node.id) }, text(node.id)))) })] }, name))), _jsx("button", { onClick: () => set({ edges: edges.filter((_entry, i) => i !== index), markdown: '' }), children: "Remove connection" })] }, index))), _jsx("button", { disabled: nodes.length < 2, onClick: () => set({
                                                edges: [
                                                    ...edges,
                                                    {
                                                        id: crypto.randomUUID(),
                                                        source: nodes[0]?.id,
                                                        target: nodes[1]?.id,
                                                    },
                                                ],
                                                markdown: '',
                                            }), children: "Add connection" })] }, "edges"));
                            if (field.name === 'content')
                                return (_jsxs("label", { children: ["Content", _jsx("textarea", { value: typeof block.markdown === 'string' ? block.markdown : text(value), onChange: (event) => set({ markdown: event.currentTarget.value }) })] }, "content"));
                            return (_jsxs("label", { children: [field.name, field.type === 'boolean' ? (_jsx("input", { type: "checkbox", checked: Boolean(value), onChange: (event) => update(event.currentTarget.checked) })) : (_jsx("textarea", { value: String(value ?? ''), onChange: (event) => update(field.type === 'number'
                                            ? Number(event.currentTarget.value)
                                            : event.currentTarget.value) }))] }, field.name));
                        }) }))] }))] }));
}
export function docsBlockNodes(options = {}) {
    const nodes = enabledDocsBlocks(options).map((type) => defineBlockObject({
        type,
        render: ({ attributes, children, node, path, readOnly }) => (_jsxs("div", { ...attributes, "data-docs-block": type, contentEditable: false, children: [_jsx(BlockEditor, { block: node, path: path, readOnly: readOnly }), children] })),
    }));
    if (options.inlineMath !== false)
        nodes.push(defineInlineObject({
            type: 'math',
            render: ({ attributes, children, node }) => (_jsxs("span", { ...attributes, contentEditable: false, children: [_jsx(DocsRichBlock, { block: { ...node, _type: 'math', inline: true } }), children] })),
        }));
    return nodes;
}
//# sourceMappingURL=blocks.js.map