import type { DocsHostAdapter, DocsHostAttachment, DocsHostTreeNode } from '../lib/host.js';
import type { DocVer } from '../lib/terra/runtime/types.js';
export declare const WORKSPACE_DEMO_STORAGE_KEY = "terra-docs-workspace-demo-v1";
export declare const WORKSPACE_DEMO_PATH = "/workspace-demo/";
export type WorkspaceDemoAsset = DocsHostAttachment & {
    bytes: number[];
    docId: string;
};
export type WorkspaceDemoDocument = {
    id: string;
    path: string;
    pathname: string;
    title: string;
    description: string;
    contributors: string[];
    updatedAt: string;
    content: unknown[];
    source: string;
    attachments: DocsHostAttachment[];
    versions: DocVer[];
};
export type WorkspaceDemoState = {
    schema: 1;
    tree: DocsHostTreeNode[];
    documents: Record<string, WorkspaceDemoDocument>;
    assets: Record<string, WorkspaceDemoAsset>;
};
export declare function createWorkspaceDemoSeed(): WorkspaceDemoState;
export declare function readWorkspaceDemoState(): WorkspaceDemoState;
export declare function writeWorkspaceDemoState(state: WorkspaceDemoState): void;
export declare function buildWorkspaceRoute(sectionId?: string, groupId?: string, leafId?: string): string;
export declare function createWorkspaceDemoHost(readOnly?: boolean): DocsHostAdapter;
export declare function routeForWorkspaceDocument(state: WorkspaceDemoState, value: string): string;
export declare function routedWorkspaceTree(state: WorkspaceDemoState, readOnly: boolean): DocsHostTreeNode[];
//# sourceMappingURL=workspace-demo-fixture.d.ts.map