import type { DocsBlockOptions } from './blocks.js';
import type { JSX } from 'react';
/** Terra's style dropdown and Carbon formatting controls, without website UI dependencies. */
export declare function Toolbar({ blocks }: {
    blocks?: DocsBlockOptions | undefined;
}): JSX.Element;
//# sourceMappingURL=_Toolbar.d.ts.map