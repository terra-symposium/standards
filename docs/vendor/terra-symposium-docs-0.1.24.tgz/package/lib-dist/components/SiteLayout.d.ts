import type { DocsSection, DocsAttachment } from '../lib/workspace-types.js';
import type { DocsNavNode } from './navigation.js';
import type { JSX, ReactNode } from 'react';
/**
 * Compatibility adapter for static React sites.
 *
 * All navigation, page chrome, modes, and document rendering are delegated to
 * the same TerraDocsWorkspace used by the local and remote host adapters.
 */
export declare function DocsSiteLayout({ title, homeHref, description, pageTitle, nodes, currentPath, hue, children, sections, attachments, rootPath, markdown, content, }: {
    title: string;
    homeHref?: string;
    description?: string;
    pageTitle?: string;
    nodes: DocsNavNode[];
    currentPath: string;
    hue?: number | null;
    children?: ReactNode;
    sections?: DocsSection[];
    attachments?: DocsAttachment[];
    rootPath?: string;
    markdown?: string;
    content?: unknown;
}): JSX.Element;
//# sourceMappingURL=SiteLayout.d.ts.map