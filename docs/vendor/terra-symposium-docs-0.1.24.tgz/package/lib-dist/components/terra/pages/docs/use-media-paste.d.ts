/** Handles editor media paste, drag, and drop interactions. */
import React from 'react';
import type { EditorRefs } from '../../../../lib/terra/runtime/types.js';
export declare function useMediaPaste(refs: React.MutableRefObject<EditorRefs>, insert: (md: string, rootEnd?: boolean) => void, uploadFile: (file: File) => Promise<string>, attachFiles: (files: File[]) => Promise<void>): void;
//# sourceMappingURL=use-media-paste.d.ts.map