/**
 * astro/src/pages/docs/_sidebar.tsx
 * Docs sidebar entrypoint, state management, and unified dialog orchestrators.
 * Folder boundary: sidebar navigation and its dialogs; the recursive tree structure remains in `_tree.tsx`.
 */
import type { Tree as TreeType } from '../../../../lib/terra/runtime/types.js';
/**
 * Renders the top collapsed header boundary on mobile-view structurally isolating context safely cleanly.
 *
 * @return {JSX.Element} Visual mobile heading frame.
 */
/**
 * Main sidebar controller connecting context providers natively driving application visual trees.
 *
 * @param {object} props - Input definitions matching specific nav tree routes.
 * @param docs - Docs input supplied to nav's operation.
 * @param pathname - Pathname input supplied to nav's operation.
 * @param permission - Permission input supplied to nav's operation.
 * @param userData - user record supplied to nav.
 *
 * @return {JSX.Element} Fully formatted UI sidebar assembly correctly binding handlers.
 */
declare const _default: ({ docs: items, pathname, permission, userData, siteTitle, siteDescription, homePath, ...props }: {
    docs: TreeType[];
    pathname: string;
    permission: import("../../../../lib/terra/runtime/types.js").DocsPermissionLevel;
    userData?: import("../../../../lib/terra/runtime/types.js").User | null;
    siteTitle?: string;
    siteDescription?: string;
    homePath?: string;
}) => JSX.Element;
export default _default;
//# sourceMappingURL=_sidebar.d.ts.map