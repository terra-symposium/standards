export declare function Toc({ title }: {
    title?: string;
}): JSX.Element | null;
//# sourceMappingURL=_toc.d.ts.map