/**
 * astro/src/pages/docs/_blocks.tsx
 * Legacy Docs utilities and TypeDoc scope selector.
 */
import React from 'react';
/**
 * Composes a full markdown syntax block identifying an image reference.
 *
 * @param src - Direct path or remote location pointer.
 * @param alt - Descriptive accessibility text representing the image payload.
 *
 * @return Clean MD string containing image formatting descriptors.
 *
 * @remarks Strips out un-intended bracketing prior to final execution.
 */
export declare function toImgMd(src: string, alt?: string): string;
/**
 * Synthesizes a valid image alt description parsing base filename syntax.
 *
 * @param v - The target filename including extension suffixes.
 *
 * @return Normalized text title equivalent.
 *
 * @remarks Scrubs file identifiers leaving human-readable labels automatically.
 */
export declare function toImgAlt(v: string): string;
/**
 * Controller input handling scope selections mapped against active documented resources.
 *
 * @param props - Interactive config mapping tracking single/multi value inputs.
 * @param value - Value supplied to ts docs select for rendering or processing.
 * @param onChange - Callback invoked for change.
 * @param className - Additional CSS classes merged into ts docs select.
 * @param variant - Visual variant controlling ts docs select's presentation.
 * @param multiple - Multiple input supplied to ts docs select's operation.
 *
 * @return Interactive dropdown presentation filtering file structures directly.
 *
 * @remarks Evaluates fetched payload blobs compiling the text formats to valid functional react representations natively.
 */
export declare function TsDocsSelect({ value, onChange, className, variant, multiple, }: {
    value?: string | string[];
    onChange: (val: string | string[]) => void;
    className?: string;
    variant?: 'dialog' | 'inline';
    multiple?: boolean;
}): React.JSX.Element;
//# sourceMappingURL=_blocks.d.ts.map