import type { Mode as ToolbarMode, ToolbarState } from '../../../../lib/terra/runtime/types.js';
/**
 * Complex Popover enabling blind/case-sensitive searches and sequential replacement inside active viewports.
 *
 * @param props - Active editing mode and toolbar state used to find text and apply replacements in the current editor.
 * @param {ToolbarMode} props.mode - The active interface mode determining search limits.
 * @param {ToolbarState | null} props.toolbar - System toolbar state reference to execute replacements.
 *
 * @return {JSX.Element | null} The Find and Replace popover or null in view mode.
 */
export declare function FindReplace({ mode, toolbar, }: {
    mode: ToolbarMode;
    toolbar: ToolbarState | null;
}): JSX.Element | null;
//# sourceMappingURL=_toolbar-find-replace.d.ts.map