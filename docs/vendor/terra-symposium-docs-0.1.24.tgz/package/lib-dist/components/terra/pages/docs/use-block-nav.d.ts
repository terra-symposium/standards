/** Maintains keyboard, pointer, and selection navigation across Docs editor blocks. */
import React from 'react';
import type { EditorRefs } from '../../../../lib/terra/runtime/types.js';
export declare function useBlockNav(refs: React.MutableRefObject<EditorRefs>): void;
//# sourceMappingURL=use-block-nav.d.ts.map