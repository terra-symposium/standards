/**
 * astro/src/components/editor/docs/_math_inline.tsx
 * Read-only Docs math inline renderer for the shared Terra content editor.
 */
import type { InlineObjectRenderProps } from '@portabletext/editor';
/**
 * Renders a read-only Docs formula as an inline Portable Text object.
 *
 * @param props - Portable Text inline-object attributes, children, and node.
 *
 * @return Inline rendered formula.
 */
export default function MathInline({ attributes: attrs, children, node, }: InlineObjectRenderProps): React.JSX.Element;
//# sourceMappingURL=_math_inline.d.ts.map