/**
 * astro/src/components/editor/docs/_Embed.tsx
 */
import type { DocsBlock } from '../types.js';
/**
 * Renders the embed component.
 *
 * @param props - Embed block data containing the external source and title.
 *
 * @return Embedded content, or null when no source is available.
 */
export declare function Embed({ block, }: {
    block: DocsBlock<'embed'>;
}): JSX.Element | null;
//# sourceMappingURL=_Embed.d.ts.map