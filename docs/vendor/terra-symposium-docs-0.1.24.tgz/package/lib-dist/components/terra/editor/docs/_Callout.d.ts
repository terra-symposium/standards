/** Docs callout renderer with view and edit modes. */
import type { DocsBlock, PortableTextBlockRendererProps } from '../types.js';
/** Sanity Portable Text callout data consumed by the docs editor and renderer. */
type CalloutBlock = DocsBlock<'callout'>;
/** Adapts Portable Text's block-object contract to the callout renderer. */
/**
 * Renders the renderCallout component.
 *
 * @param props - Portable Text renderer attributes, nested children, callout node, path, and read-only mode.
 * @returns The callout renderer in editable or read-only mode.
 */
export declare function renderCallout({ attributes: attrs, children, node, path, readOnly, }: PortableTextBlockRendererProps<CalloutBlock>): React.JSX.Element;
export {};
//# sourceMappingURL=_Callout.d.ts.map