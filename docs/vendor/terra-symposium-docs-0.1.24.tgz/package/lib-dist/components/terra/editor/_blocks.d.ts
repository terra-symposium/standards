/**
 * astro/src/components/editor/_blocks.tsx
 * Reusable structural blocks and image editing primitives for portable editors.
 */
import React from 'react';
import type { ReactNode } from 'react';
/**
 * Renders the tabs group component.
 *
 * @param children - Tab content rendered inside the tabs group.
 * @param onAdd - Adds a new empty tab to the group.
 * @param onDelete - Removes the tab at the supplied index.
 * @param onRename - Persists a new title for the tab at the supplied index.
 */
export declare const TabsGroup: ({ children, onAdd, onDelete, onRename, }: {
    children: ReactNode;
    onAdd?: () => void;
    onDelete?: (index: number) => void;
    onRename?: (index: number, title: string) => void;
}) => React.JSX.Element;
/**
 * Renders the tabs item component.
 *
 * @param children - Content rendered inside the block wrapper.
 */
export declare const TabsItem: ({ children, }: {
    children: ReactNode;
    title: string;
}) => React.JSX.Element;
/**
 * Renders the accordion group component.
 *
 * @param children - Content rendered inside the block preview.
 */
export declare const AccordionGroup: ({ children }: {
    children: ReactNode;
}) => React.JSX.Element;
/**
 * Renders the accordion item component.
 *
 * @param title - Block title displayed above the content.
 * @param children - Block content rendered below the title.
 * @param onDelete - Removes this accordion section from its parent group.
 * @param onRename - Persists a new title for this accordion section.
 */
export declare const AccordionItem: ({ title, children, onDelete, onRename, }: {
    children: ReactNode;
    title: string;
    onDelete?: () => void;
    onRename?: (title: string) => void;
}) => React.JSX.Element;
/**
 * Renders the editor tabs list component.
 *
 * @param props - Tab definitions, active value, and optional mutation callbacks.
 *
 * @return The tab list and controls for selecting, renaming, deleting, or adding editor tabs.
 */
export declare function EditorTabsList({ tabs, value: a, onValueChange: onValChange, onRename, onDelete, onAdd, }: {
    onAdd?: () => void;
    onDelete?: (val: string) => void;
    onRename?: (val: string, title: string) => void;
    onValueChange: (val: string) => void;
    tabs: {
        fallback?: string;
        title: string;
        value: string;
    }[];
    value: string;
}): React.JSX.Element;
//# sourceMappingURL=_blocks.d.ts.map