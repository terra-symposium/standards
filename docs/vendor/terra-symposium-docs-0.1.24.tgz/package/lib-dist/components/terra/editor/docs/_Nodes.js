import { jsx as _jsx } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/components/editor/docs/_Nodes.tsx
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// API
import { cn } from '../../../../lib/terra/runtime/runtime.js';
import { decodeNodesPayload } from '../../../../lib/terra/runtime/nodes.js';
// COMPONENTS
import Canvas from '../../flow/Nodes.js';
import { ErrorBoundary } from '../../ui.js';
/*//////////////////////////////////////////////////
HELPERS
//////////////////////////////////////////////////*/
/**
 * Decodes and renders a Docs flow diagram.
 *
 * @param props - Node data, optional styling class, and rendering state used to display a graph preview.
 *
 * @return The graph preview for the supplied node data.
 */
function NodesRenderer(props) {
    const { className, nodes: rawNodes, edges: rawEdges, direction, height, nodeSep, rankSep, proximityConnect, ...rest } = props;
    const resolvedHeight = Number.isFinite(Number(height)) ? Number(height) : 384;
    return (_jsx(ErrorBoundary, { name: "Nodes", children: _jsx("div", { className: cn('docs-block relative my-0 flow-root transition-all duration-200 [&>:first-child]:!mt-0 [&>:last-child]:!mb-0', className), "data-docs-editor-block": "Nodes", style: { height: resolvedHeight, width: '100%' }, contentEditable: false, suppressContentEditableWarning: true, children: _jsx(Canvas, { ...rest, direction: direction, height: resolvedHeight, nodeSep: nodeSep, rankSep: rankSep, proximityConnect: proximityConnect, nodes: decodeNodesPayload(rawNodes).filter((n) => {
                    if (!n || typeof n !== 'object')
                        return false;
                    const val = n;
                    return (typeof val.id === 'string' &&
                        Boolean(val.data && typeof val.data === 'object') &&
                        Boolean(val.position && typeof val.position === 'object'));
                }), edges: decodeNodesPayload(rawEdges).filter((e) => {
                    if (!e || typeof e !== 'object')
                        return false;
                    const val = e;
                    return (typeof val.id === 'string' &&
                        typeof val.source === 'string' &&
                        typeof val.target === 'string');
                }), className: className }) }) }));
}
Object.assign(NodesRenderer, { displayName: 'DocsNodesRenderer' });
/**
 * Renders the nodes block component.
 *
 * @param props - Portable Text node props passed to the renderer.
 *
 * @return Rendered documentation node content.
 */
export function NodesBlock({ block, }) {
    return (_jsx(ErrorBoundary, { name: "NodesBlock", children: _jsx(NodesRenderer, { ...(block.nodes === undefined
                ? {}
                : { nodes: block.nodes }), ...(block.edges === undefined
                ? {}
                : { edges: block.edges }), ...(block.direction === 'TB' || block.direction === 'LR'
                ? { direction: block.direction }
                : {}), ...(block.height === undefined ? {} : { height: block.height }), ...(block.nodeSep === undefined ? {} : { nodeSep: block.nodeSep }), ...(block.proximityConnect === undefined
                ? {}
                : { proximityConnect: block.proximityConnect }), ...(block.rankSep === undefined ? {} : { rankSep: block.rankSep }) }) }));
}
Object.assign(NodesBlock, { displayName: 'DocsNodesBlock' });
//# sourceMappingURL=_Nodes.js.map