import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { EditorProvider, PortableTextEditable, defineBlockObject, defineInlineObject, } from '@portabletext/editor';
import { EventListenerPlugin, NodePlugin } from '@portabletext/editor/plugins';
import { createDocsSchema, safeLink } from '../../../lib/schema.js';
import { Embed } from './docs/_Embed.js';
import { renderCallout } from './docs/_Callout.js';
import { renderCode } from './docs/_DocsCode.js';
import { renderImage } from './docs/_DocsImage.js';
import { renderMathBlock } from './docs/_Math.js';
import MathInline from './docs/_math_inline.js';
import { NodesBlock } from './docs/_Nodes.js';
import { Raw } from './docs/_Raw.js';
import { renderTable } from './docs/_Table.js';
import { renderSections } from './docs/_Tabs.js';
import { TsDocs } from './docs/_TsDocs.js';
import { DocsHeading } from './docs/heading.js';
import { createElement } from 'react';
const rendererByType = {
    accordion: renderSections,
    callout: renderCallout,
    code: renderCode,
    docImage: renderImage,
    embed: ({ attributes, children, node }) => (_jsxs("div", { ...attributes, "data-docs-editor-block": "Embed", children: [_jsx(Embed, { block: node }), children] })),
    math: renderMathBlock,
    nodes: ({ attributes, children, node }) => (_jsxs("div", { ...attributes, children: [_jsx(NodesBlock, { block: node }), children] })),
    raw: ({ attributes, children, node }) => (_jsxs("div", { ...attributes, children: [_jsx(Raw, { block: node }), children] })),
    table: renderTable,
    tabs: renderSections,
    tsDocs: ({ attributes, children, node }) => (_jsxs("div", { ...attributes, children: [_jsx(TsDocs, { block: node }), children] })),
};
function docsNodes() {
    const blocks = Object.entries(rendererByType).map(([type, render]) => defineBlockObject({ type, render: (props) => render(props) ?? _jsx(_Fragment, {}) }));
    blocks.push(defineInlineObject({ type: 'math', render: (props) => _jsx(MathInline, { ...props }) }));
    return blocks;
}
/** Docs-only Portable Text profile extracted from the website's shared editor. */
export function TerraContentEditor({ content = [], onChange, readOnly = false, resetKey, }) {
    return (_jsx("div", { "data-terra-content-editor": true, children: _jsxs(EditorProvider, { initialConfig: { schemaDefinition: createDocsSchema(), initialValue: content, readOnly }, children: [_jsx(EventListenerPlugin, { on: (event) => {
                        if (event.type === 'mutation' && !readOnly)
                            onChange?.(event.value ?? []);
                    } }), _jsx(NodePlugin, { nodes: docsNodes() }), _jsx(PortableTextEditable, { "aria-label": readOnly ? 'Document viewer' : 'Document editor', contentEditable: !readOnly, className: "terra-docs-content outline-none", renderStyle: ({ children, schemaType }) => {
                        const style = schemaType.value;
                        if (style === 'blockquote')
                            return _jsx("blockquote", { children: children });
                        if (readOnly && typeof style === 'string' && /^h[2-6]$/.test(style))
                            return (_jsx(DocsHeading, { level: style, children: children }));
                        if (typeof style === 'string' && /^h[1-6]$/.test(style))
                            return createElement(style, {}, children);
                        return _jsx("p", { children: children });
                    }, renderDecorator: ({ children, value }) => value === 'strong' ? (_jsx("strong", { children: children })) : value === 'em' ? (_jsx("em", { children: children })) : value === 'underline' ? (_jsx("u", { children: children })) : value === 'strike-through' ? (_jsx("s", { children: children })) : value === 'code' ? (_jsx("code", { children: children })) : (_jsx(_Fragment, { children: children })), renderAnnotation: ({ children, value }) => {
                        const href = safeLink(value.href);
                        return href ? _jsx("a", { href: href, children: children }) : _jsx(_Fragment, { children: children });
                    } })] }, resetKey) }));
}
//# sourceMappingURL=TerraContentEditor.js.map