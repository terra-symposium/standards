import { jsx as _jsx } from "react/jsx-runtime";
// @ts-nocheck -- source-preserving extraction; public host contracts are typed in src/host.ts.
/**
 * astro/src/components/editor/docs/_Embed.tsx
 */
/*//////////////////////////////////////////////////
IMPORTS
//////////////////////////////////////////////////*/
// COMPONENTS
import { ErrorBoundary } from '../../ui.js';
/*//////////////////////////////////////////////////
HELPERS
//////////////////////////////////////////////////*/
/**
 * Renders the embed component.
 *
 * @param props - Embed block data containing the external source and title.
 *
 * @return Embedded content, or null when no source is available.
 */
export function Embed({ block, }) {
    if (!block.src)
        return null;
    return (_jsx(ErrorBoundary, { name: "Embed", children: _jsx("iframe", { className: "my-6 w-full border-0", src: block.src, title: block.title ?? block.src, style: { height: block.height ?? '500px', width: block.width ?? '100%' } }) }));
}
Object.assign(Embed, { displayName: 'DocsEmbed' });
//# sourceMappingURL=_Embed.js.map