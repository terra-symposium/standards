/**
 * astro/src/components/flow/_layout.ts
 * Pure Dagre layout primitives shared by flow UI and testable graph helpers.
 */
import Dagre from '@dagrejs/dagre';
import type { DagreNode, FlowNodeLike, FlowSize } from '../runtime/types.js';
import type { Edge } from '@xyflow/react';
/**
 * Handles layout graph.
 *
 * @param nodes - Nodes to position in the generated graph.
 * @param edges - Directed connections between graph nodes.
 * @param direction - Dagre rank direction used for layout.
 * @param nodeSep - Minimum separation between adjacent nodes.
 * @param rankSep - Minimum separation between graph ranks.
 * @param opts - Callbacks for measuring, registering, and placing nodes.
 *
 * @return Positioned nodes and the computed graph height.
 */
export declare function layoutGraph<TNode extends FlowNodeLike>(nodes: TNode[], edges: Pick<Edge, 'source' | 'target'>[], direction: 'TB' | 'LR', nodeSep: number, rankSep: number, opts: {
    getSize: (node: TNode) => FlowSize;
    getGroupId?: (node: TNode) => string | undefined;
    getCustomPosition?: (node: TNode) => import('@xyflow/react').XYPosition | undefined;
    registerNode?: (graph: Dagre.graphlib.Graph, node: TNode, size: FlowSize) => void;
    placeNode?: (node: TNode, dagreNode: DagreNode | undefined, persisted: import('@xyflow/react').XYPosition | undefined) => TNode;
}): {
    positionedNodes: TNode[];
    graphHeight: number;
};
//# sourceMappingURL=_layout.d.ts.map