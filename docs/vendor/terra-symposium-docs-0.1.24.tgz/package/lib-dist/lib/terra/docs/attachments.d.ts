import type { AttchType } from '../runtime/types.js';
export declare const ATTCH_TYPES: readonly ["document", "image", "youtube", "website", "tsdocs", "other"];
export declare const $attachmentFilter: import("nanostores").PreinitializedWritableAtom<AttchType[]> & object;
//# sourceMappingURL=attachments.d.ts.map