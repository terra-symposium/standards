import type { Mode } from '../runtime/types.js';
export declare function navigateDocs({ href, mode }: {
    href: string;
    mode: Mode;
}): void;
//# sourceMappingURL=navigation.d.ts.map