/**
 * Executes an async action safely behind a circuit breaker and transition lock.
 *
 * @param action - Async action executed by the guarded operation.
 * @param fallbackErr - Error value returned when the action cannot complete.
 * @param onStart - Optional callback invoked before the action begins.
 * @param onEnd - Optional callback invoked after the action settles.
 */
export declare const runMutation: (action: () => Promise<void>, fallbackErr: string, onStart?: () => void, onEnd?: () => void) => Promise<void>;
//# sourceMappingURL=mutations.d.ts.map