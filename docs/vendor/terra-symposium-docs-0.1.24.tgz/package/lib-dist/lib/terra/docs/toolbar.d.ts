/** Maps the current DOM selection to the Docs toolbar block kind. */
/**
 * Determines which Docs toolbar block is active at the current editor selection.
 *
 * @param el - Focused element inside the active Docs editor.
 * @param vals - Supported block kinds that may be returned for custom content.
 *
 * @return The active block kind, or `null` when the selection is outside a supported block.
 */
export declare function toolbarFocusValue(el: Element, vals: readonly string[]): string | null;
//# sourceMappingURL=toolbar.d.ts.map