import type { EditorSel, Mode, ToolbarState, Transition } from '../runtime/types.js';
export declare function useAtom<Value>(store: {
    get(): Value;
    subscribe(listener: (val: Value) => void): () => void;
}): Value;
export declare const $mode: import("nanostores").PreinitializedWritableAtom<Mode> & object;
/** Shares the active leaf title across Docs surfaces. */
export declare const $leafTitle: import("nanostores").PreinitializedWritableAtom<{
    path: string;
    title: string;
} | null> & object;
/**
 * Global transition flag for docs navigation and mutations.
 *
 * @returns A boolean atom.
 *
 * @remarks This lets the UI disable inputs while a transition is active.
 */
export declare const $transition: import("nanostores").PreinitializedWritableAtom<boolean> & object;
/**
 * Current toolbar state.
 *
 * @returns A nullable toolbar atom.
 *
 * @remarks The toolbar is controlled centrally so overlays can share the same focus state.
 */
export declare const $toolbar: import("nanostores").PreinitializedWritableAtom<ToolbarState | null> & object;
/**
 * Hydration counter for docs editor widgets.
 *
 * @returns A numeric atom tracking hydration depth.
 *
 * @remarks This is used to delay interactions until the editor tree is ready.
 */
export declare const $hydrating: import("nanostores").PreinitializedWritableAtom<number> & object;
/**
 * Surface readiness state for docs editing.
 *
 * @returns A nullable mode atom.
 *
 * @remarks The value flips once the interactive surface is available.
 */
export declare const $surfaceReady: import("nanostores").PreinitializedWritableAtom<Mode | null> & object;
export declare const $editReadyPath: import("nanostores").PreinitializedWritableAtom<string | null> & object;
/** Shared cursor state so toolbar focus can preserve the last insertion point visibly. */
export declare const $cursor: import("nanostores").PreinitializedWritableAtom<EditorSel | null> & object;
/** Persisted caret snapshot used for the simulated cursor overlay when focus leaves the editor. */
export declare const $cursorGhost: import("nanostores").PreinitializedWritableAtom<EditorSel | null> & object;
/** Linear caret bookmark used to simulate the visible cursor without relying on DOM focus. */
export declare const $cursorTrack: import("nanostores").PreinitializedWritableAtom<(Pick<EditorSel, "box" | "collapsed" | "visible"> & {
    anchor: number;
    focus: number;
    range: [number, number];
}) | null> & object;
/**
 * Cursor position snapshot for the docs editor.
 *
 * @returns A nullable cursor atom.
 *
 * @remarks This duplicates the visible cursor state for consumers that need direct position access.
 */
export declare const $cursorPosition: import("nanostores").PreinitializedWritableAtom<EditorSel | null> & object;
/**
 * Unsaved docs draft flags.
 *
 * @returns A map store keyed by document id.
 *
 * @remarks This store only tracks presence, not draft content.
 */
export declare const $unsavedDrafts: import("nanostores").PreinitializedMapStore<Record<string, boolean>> & object;
/**
 * In-memory docs draft cache.
 *
 * @returns A map of draft payloads and metadata.
 *
 * @remarks This cache is process-local and intentionally not persisted.
 */
export declare const memoryDrafts: Map<string, {
    source: string;
    draft: unknown;
    metadata: unknown;
}>;
/**
 * Sidebar visibility state for the docs editor.
 *
 * @returns A persisted boolean atom.
 *
 * @remarks The default keeps the sidebar open for discoverability.
 */
export declare const $sidebar: import("nanostores").PreinitializedWritableAtom<boolean> & object;
/**
 * Shared transition store for docs UI coordination.
 *
 * @returns transition store object.
 *
 * @remarks This is kept as a plain object so listeners can subscribe without extra abstractions.
 */
export declare const transitionStore: {
    transition: Transition;
    restore: (() => void) | null;
    listeners: Set<() => void>;
};
/**
 * Sets the active docs transition state.
 *
 * @param transition - Next transition state.
 *
 * @remarks The boolean store mirrors the non-idle state for simpler UI consumers.
 */
export declare function setTransition(transition: Transition): void;
/**
 * Clears the active docs transition state.
 *
 *
 * @remarks Idle is the only state that leaves the transition flag unset.
 */
export declare function clearTransition(): void;
/**
 * Subscribes to the current docs transition state.
 *
 * @return use Transition State.
 *
 * @remarks This is used by components that need to react to local mutation states.
 */
export declare function useTransitionState(): Transition;
/**
 * Shared editor transition context.
 *
 * @returns transition context object.
 *
 * @remarks The provider keeps layout and loading overlays in sync.
 */
export declare const TransitionCtx: import("react").Context<{
    setSourceReady: (ready: boolean) => void;
    setLoading: (loading: boolean) => void;
} | null>;
export declare const EditStateCtx: import("react").Context<{
    busy: import("../runtime/types.js").EditorState["busy"];
    code: string;
    draft: import("../runtime/types.js").Draft;
    dirty: boolean;
    loaded?: boolean;
    mark?: () => void;
    references?: import("react").MutableRefObject<import("../runtime/types.js").EditorRefs>;
    setSrc?: (val: string) => void;
    source?: string;
    state?: import("../runtime/types.js").EditorState;
    save: (code?: string, opts?: {
        force?: boolean;
        format?: boolean;
    }) => void;
    setCode: (val: string) => void;
    update: (patch: Partial<import("../runtime/types.js").Draft>) => void;
} | null>;
/**
 * Context for the docs editor surface.
 *
 * @returns surface context object.
 *
 * @remarks This lets nested components reach the active editor surface without prop drilling.
 */
export declare const EditorSurfaceCtx: import("react").Context<{
    [x: string]: unknown;
} | null>;
export declare const $editorMounts: import("nanostores").PreinitializedWritableAtom<{
    expected: string[];
    mounted: string[];
    path: string | null;
}> & object;
/**
 * Handles reset editor mounts.
 *
 * @param path - Source or route path resolved for reset editor mounts.
 * @param expected - Expected input supplied to reset editor mounts's operation.
 */
export declare function resetEditorMounts(path: string | undefined, expected: string[]): void;
/**
 * Handles set editor mount.
 *
 * @param path - Source or route path resolved for set editor mount.
 * @param reporter - Reporter input supplied to set editor mount's operation.
 * @param mounted - Mounted input supplied to set editor mount's operation.
 * @param kind - Content kind that selects set editor mount's renderer.
 */
export declare function setEditorMount(path: string | undefined, reporter: string | undefined, mounted: boolean, kind?: string): void;
//# sourceMappingURL=state.d.ts.map