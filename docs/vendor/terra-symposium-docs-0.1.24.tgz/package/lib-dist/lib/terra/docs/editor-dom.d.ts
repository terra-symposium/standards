import type { EditorSel } from '../runtime/types.js';
import type { EditorView } from '@codemirror/view';
export declare const document: Document;
export declare function getCollapsedRange(): Range | null;
/**
 * Captures child-node indexes from a root node to a target so the target can be found after DOM updates.
 *
 * @param root - DOM node whose child tree defines the path origin.
 * @param tgt - Descendant node to locate, or `null` when no selection node exists.
 *
 * @return The sequence of child indexes from the root, or `null` when the target is not inside it.
 */
export declare function captureNodePath(root: Node, tgt: Node | null): number[] | null;
/**
 * Converts a DOM text position into its character offset within the editor's complete text flow.
 *
 * @param root - Editor element whose text nodes define the linear text flow.
 * @param node - Selected DOM node whose position should be measured.
 * @param offset - Character offset within a text node or child index within an element node.
 *
 * @return The character offset from the beginning of the editor, or `null` if the node is absent or outside it.
 */
export declare function captureLinearOffset(root: HTMLElement, node: Node | null, offset?: number): number | null;
/**
 * Finds the DOM caret range at a character offset in the editor's text flow.
 *
 * @param root - Editor element whose text nodes should be traversed.
 * @param i - Character offset from the start of the editor.
 *
 * @return A collapsed range at the requested offset, or `null` for an invalid or out-of-range offset.
 */
export declare function resolveLinearOffset(root: HTMLElement, i?: number): Range | null;
/**
 * Handles paste md.
 *
 * @param insert - Insert input supplied to paste md's operation.
 * @param md - Md input supplied to paste md's operation.
 * @param selection - Selection input supplied to paste md's operation.
 */
export declare function pasteMd(insert: (md: string, rootEnd?: boolean, selection?: EditorSel | null) => void, md: string, selection?: EditorSel | null): void;
export declare function codeViewOf(): EditorView | null;
/**
 * Converts raw HTML into structured md, maintaining basic formatting constraints.
 *
 * @param html - Raw HTML to convert into the editor's Markdown representation.
 *
 * @return Markdown text with supported block and inline formatting preserved.
 */
export declare function htmlToMd(html: string): string;
//# sourceMappingURL=editor-dom.d.ts.map