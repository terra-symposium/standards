/**
 * astro/src/actions/docs/nodes.ts
 * Pure utility functions for parsing and rendering node blocks.
 * Extracted from the React component to prevent circular dependencies.
 */
import type { Md } from './types.js';
/**
 * Canonical fallback `Nodes` block used when a document has no explicit graph markup.
 *
 * @remarks
 * The template keeps the editor and migration paths aligned on a minimal valid node payload.
 */
export declare const EMPTY_NODES = "\n\n<Nodes\n  node_data={[\n    { id: 'start', type: 'origin', data: { title: 'Start' } }\n  ]}\n  edges_data={[]}\n  direction=\"TB\"\n  height={400}\n/>\n\n";
/**
 * Handles the nodes route.
 */
export declare const NODES: {
    readonly empty: "\n\n<Nodes\n  node_data={[\n    { id: 'start', type: 'origin', data: { title: 'Start' } }\n  ]}\n  edges_data={[]}\n  direction=\"TB\"\n  height={400}\n/>\n\n";
    readonly jsx: "\n\n<Nodes\n  node_data={[\n    { id: 'start', type: 'origin', data: { title: 'Start' } }\n  ]}\n  edges_data={[]}\n  direction=\"TB\"\n  height={400}\n/>\n\n";
    readonly fields: readonly [{
        readonly key: "direction";
        readonly kind: "string";
        readonly label: "Direction";
        readonly placeholder: "TB or LR";
        readonly tooltip: "Graph flow direction.";
    }, {
        readonly key: "nodes";
        readonly kind: "expression";
        readonly label: "Nodes";
        readonly placeholder: "[...]";
        readonly textarea: true;
        readonly tooltip: "Node defs.";
    }, {
        readonly key: "edges";
        readonly kind: "expression";
        readonly label: "Edges";
        readonly placeholder: "[...]";
        readonly textarea: true;
        readonly tooltip: "Edge defs.";
    }, {
        readonly key: "height";
        readonly kind: "expression";
        readonly label: "Height";
        readonly placeholder: "384";
        readonly tooltip: "Canvas height.";
    }, {
        readonly key: "nodeSep";
        readonly kind: "expression";
        readonly label: "node_sep";
        readonly placeholder: "50";
        readonly tooltip: "Node x-spacing.";
    }, {
        readonly key: "rankSep";
        readonly kind: "expression";
        readonly label: "rank_sep";
        readonly placeholder: "5";
        readonly tooltip: "Rank y-spacing.";
    }, {
        readonly key: "proximityConnect";
        readonly kind: "boolean";
        readonly label: "proximity";
        readonly tooltip: "Enable auto-connect.";
    }];
    readonly import: "import Nodes from '@src/pages/docs/blocks/nodes';";
    readonly keys: {
        readonly direction: "direction";
        readonly edges: "edges_data";
        readonly height: "height";
        readonly nodeSep: "node_sep";
        readonly nodes: "node_data";
        readonly proximityConnect: "proximity_connect";
        readonly rankSep: "rank_sep";
    };
    readonly rx: {
        readonly block: RegExp;
        readonly import: RegExp;
        readonly tag: RegExp;
        readonly meta: RegExp;
    };
    readonly inline: (content: string, meta?: Md) => string;
};
/**
 * Encodes node payload arrays into a serializer-safe string literal.
 *
 * @remarks
 * A template literal keeps the payload readable while preventing mdxeditor from compacting the
 * payload back into a raw array expression during code/edit round-trips.
 *
 * @param value - Node or edge array to encode for safe serializer round-tripping.
 */
export declare const encodeNodesPayload: (val: unknown) => string;
/**
 * Decodes a serializer-safe node payload back into arrays.
 *
 * @remarks
 * Accepts raw arrays, JSON strings, backtick-wrapped literals, and the newer quoted payload.
 *
 * @param value - Serialized node payload in array, JSON, or quoted literal form.
 */
export declare const decodeNodesPayload: (val: unknown) => unknown[];
/**
 * Reflows serialized `Nodes` tags into a stable multiline attribute shell.
 *
 * @param source - MDX source that may contain one or more `Nodes` tags.
 *
 * @returns Source with `Nodes` tags rewritten to a multiline layout.
 *
 * @remarks
 * This keeps the code view stable even when the MDX editor would otherwise compact the shell.
 */
export declare const fmtNodesSrc: (src: string) => string;
//# sourceMappingURL=nodes.d.ts.map