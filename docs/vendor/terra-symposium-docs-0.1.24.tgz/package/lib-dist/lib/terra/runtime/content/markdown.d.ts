/** Separates compact tabs markers before they reach the line-based block parser. */
export declare const normBlockMarkers: (md: string) => string;
/** Serializes a string literal for embedded MDX and JSX attributes. */
export declare const quote: (value: string) => string;
/**
 * Converts any code payload into a printable string before it is written into docs markup.
 *
 * @param val - Any code-like value to stringify.
 *
 * @return Printable code string used by the markdown and MDX serializers.
 *
 * @remarks
 * Prefers compact primitives and pretty-prints structured values.
 */
export declare function stringifyCodeValue(val: unknown): string;
/**
 * Serializes fenced code into the canonical `<Code>` JSX used by docs content.
 *
 * @param lang - Code fence language label.
 * @param val - Raw code text.
 *
 * @return Canonical `Code` JSX for the code block.
 *
 * @remarks
 * The code payload is HTML-escaped so it can round-trip through MDX safely.
 */
export declare function codeJsx(lang: string | undefined, val: string): string;
/**
 * Handles code src jsx.
 *
 * @param lang - Code language label used for the generated code block.
 * @param src - Source code text to wrap in the code block.
 */
export declare const codeSrcJsx: (lang: string | undefined, src: string) => string;
/**
 * Normalizes markdown fences into the canonical Code JSX form.
 *
 * @param src - Markdown, fenced code, or legacy HTML source.
 *
 * @return Canonical `Code` JSX where code blocks were found.
 *
 * @remarks
 * The function leaves unrelated prose untouched so callers can run it on whole documents.
 */
export declare function toCodeJsx(src: string): string;
/**
 * Renders a markdown pipe table into HTML when the row widths and separator row are valid.
 *
 * @param md - Table markdown to render.
 * @param renderCell - Cell renderer used for each value.
 *
 * @returns HTML table markup when the input is a valid pipe table, otherwise `null`.
 *
 * @remarks
 * Callers can supply a custom cell renderer to preserve nested markdown or JSX.
 */
export declare const mdTableToHtml: (md: string, renderCell?: (val: string) => string) => string | null;
/**
 * Converts plain markdown into HTML for the serializer's fallback path.
 *
 * @param value - Markdown source to parse.
 *
 * @returns Rendered HTML string used when markdown does not map to richer docs blocks.
 */
export declare const renderMd: (val: string) => string;
/**
 * Handles strip nested anchors.
 *
 * @param val - Table cell markup to sanitize before it is embedded in a Docs table.
 */
export declare const stripNestedAnchors: (val: string) => string;
/**
 * Handles sanitize table html.
 *
 * @param val - Table markup whose inline styles should be removed.
 */
export declare const sanitizeTableHtml: (val: string) => string;
/**
 * Formats raw table HTML with consistent indentation so docs tables round-trip cleanly.
 *
 * @param value - Table HTML to format.
 *
 * @returns Formatted table HTML string with stable indentation.
 */
export declare const fmtRawTable: (val: string) => string;
/** Identifies complete canonical HTML table markup. */
export declare const TABLE_TAG: RegExp;
/**
 * Handles atomic table html.
 *
 * @param val - Complete table markup captured from a Docs source block.
 */
export declare const atomicTableHtml: (val: string) => string;
/**
 * Normalizes block spacing in serialized docs source.
 *
 * @param src - Markdown or MDX source to normalize.
 *
 * @returns Source with headings and block delimiters separated onto their own lines.
 */
export declare const normDocsSpacing: (src: string) => string;
/**
 * Renders a Portable Text table block into HTML with a header row followed by body rows.
 *
 * @param rows - Table rows to serialize.
 *
 * @returns HTML table markup for the stored Portable Text rows.
 */
//# sourceMappingURL=markdown.d.ts.map