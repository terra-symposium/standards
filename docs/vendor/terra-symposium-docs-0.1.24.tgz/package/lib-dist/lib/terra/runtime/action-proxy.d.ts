import type { DocsActionOperation, DocsActionResult } from '../../host.js';
type ActionCall<T> = (input?: unknown) => Promise<DocsActionResult<T>>;
type ActionTree = {
    read: {
        asset: {
            get: ActionCall<ArrayBuffer>;
        };
        doc: {
            attachments: ActionCall<unknown[]>;
            get: ActionCall<Record<string, unknown>>;
            list: ActionCall<string[]>;
        };
        external: {
            pdf: ActionCall<{
                pdfBase64?: string;
            }>;
            youtube: ActionCall<{
                title?: unknown;
                transcript?: unknown;
            }>;
        };
        tsdocs: ActionCall<{
            docs?: unknown;
        }>;
        util: {
            pathname: ActionCall<string>;
        };
    };
    write: {
        asset: {
            upload: ActionCall<{
                message?: unknown;
                path?: string;
                src?: string;
                compressedSize?: number;
                name?: string;
            }>;
        };
    };
};
export declare function configureDocsActionProxy(handler: <T = unknown>(operation: DocsActionOperation, input?: unknown) => Promise<DocsActionResult<T>>): void;
/** Internal compatibility bridge for the original UI's nested host-action calls. */
export declare const actions: ActionTree;
export {};
//# sourceMappingURL=action-proxy.d.ts.map