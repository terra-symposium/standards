import type { DocBody } from './types.js';
export declare const toPortableBody: (value: unknown) => DocBody;
export declare const currLeafBody: (value: unknown) => DocBody;
export declare const currLeafSrc: (value: unknown) => string;
//# sourceMappingURL=leaf.d.ts.map