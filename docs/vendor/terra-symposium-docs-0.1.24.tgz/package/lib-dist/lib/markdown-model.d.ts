import type { DocsValue } from '../components/Docs.js';
import type { DocsBlockOptions } from '../components/blocks.js';
/** Decode Markdown without dropping unsupported syntax; opaque tokens become raw blocks. */
export declare function markdownToDocsValue(markdown: string, options?: DocsBlockOptions): DocsValue;
/** Serialize supported visual blocks and keep every opaque raw token verbatim. */
export declare function docsValueToMarkdown(value: DocsValue): string;
//# sourceMappingURL=markdown-model.d.ts.map