# Typeface credits

- **Avara Bold and Bold Italic** — designed by Raphaël Bastide, with contributions by Wei Huang, Lucas Le Bihan, Walid Bouchouchi, and Jérémy Landes; released by [Velvetyne Type Foundry](https://velvetyne.fr/fonts/avara/). Licensed under the SIL Open Font License 1.1. See [licenses/OFL-1.1.txt](licenses/OFL-1.1.txt).
- **AUTHENTIC Sans 90, 130, and 150** — distributed by [AUTHENTIC](https://authentic.website/sans) under the WTFPL.

The font files are distributed unchanged from the copies already used by the Terra Symposium website. Their licenses are separate from the Apache-2.0 license for this package.
