import type { JSX } from 'react';
export type DocsAttachment = {
    title: string;
    href: string;
    type?: string;
    size?: number;
};
export type DocsLeaf = {
    title: string;
    href: string;
    description?: string;
    updatedAt?: string;
    attachments?: DocsAttachment[];
};
export type DocsGroup = {
    title: string;
    leaves: DocsLeaf[];
};
export type DocsSection = {
    title: string;
    groups: DocsGroup[];
};
export type DocsCapabilities = {
    edit?: boolean;
    save?: boolean;
    history?: boolean;
};
export type DocsMode = 'view' | 'attachments' | 'edit';
export declare function DocsWorkspaceNavigation({ sections, currentPath }: {
    sections: DocsSection[];
    currentPath: string;
}): JSX.Element;
export declare function DocsWorkspaceToolbar({ attachments, capabilities, onEdit, onSave, onHistory }: {
    attachments?: DocsAttachment[];
    capabilities?: DocsCapabilities | undefined;
    onEdit?: (() => void) | undefined;
    onSave?: (() => void) | undefined;
    onHistory?: (() => void) | undefined;
}): JSX.Element;
export declare function DocsAttachmentsView({ attachments }: {
    attachments?: DocsAttachment[];
}): JSX.Element;
//# sourceMappingURL=workspace.d.ts.map