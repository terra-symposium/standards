import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { CaretDown, Checkmark, Link, TextBold, TextItalic, TextStrikethrough, TextUnderline, } from '@carbon/icons-react';
import { useEditor, useEditorSelector } from '@portabletext/editor';
import { getActiveStyle, isActiveAnnotation, isActiveDecorator, } from '@portabletext/editor/selectors';
import * as Select from '@radix-ui/react-select';
import { useId, useRef, useState } from 'react';
import { safeLink, schema } from './schema.js';
/** Terra's style dropdown and Carbon formatting controls, without website UI dependencies. */
export function Toolbar() {
    const editor = useEditor();
    const snapshot = useEditorSelector(editor, (state) => state);
    const selection = useRef(null);
    const linkDialog = useRef(null);
    const linkId = useId();
    const [linkValue, setLinkValue] = useState('');
    const [linkError, setLinkError] = useState(false);
    return (_jsxs("div", { className: "terra-docs-toolbar", role: "toolbar", "aria-label": "Editor controls", children: [_jsxs(Select.Root, { value: getActiveStyle(snapshot) ?? 'normal', onValueChange: (style) => {
                    if (selection.current)
                        editor.send({ type: 'select', at: selection.current });
                    editor.send({ type: 'style.toggle', style });
                    editor.send({ type: 'focus' });
                }, children: [_jsxs(Select.Trigger, { className: "terra-docs-select", "aria-label": "Block type", onPointerDownCapture: () => {
                            selection.current = editor.getSnapshot().context.selection;
                        }, onKeyDownCapture: () => {
                            selection.current = editor.getSnapshot().context.selection;
                        }, children: [_jsx(Select.Value, { placeholder: "Text" }), _jsx(Select.Icon, { children: _jsx(CaretDown, { size: 16, "aria-hidden": "true" }) })] }), _jsx(Select.Portal, { children: _jsx(Select.Content, { className: "terra-docs-select-menu", position: "popper", sideOffset: 8, onCloseAutoFocus: (event) => event.preventDefault(), children: _jsx(Select.Viewport, { children: schema.styles.map(({ name, title }) => (_jsxs(Select.Item, { value: name, className: "terra-docs-select-item", children: [_jsx(Select.ItemText, { children: title }), _jsx(Select.ItemIndicator, { children: _jsx(Checkmark, { size: 16, "aria-hidden": "true" }) })] }, name))) }) }) })] }), _jsx("span", { className: "terra-docs-toolbar-divider", "aria-hidden": "true" }), [
                { Icon: TextBold, name: 'strong', label: 'Bold' },
                { Icon: TextItalic, name: 'em', label: 'Italic' },
                { Icon: TextUnderline, name: 'underline', label: 'Underline' },
                { Icon: TextStrikethrough, name: 'strike-through', label: 'Strikethrough' },
            ].map(({ Icon, name, label }) => (_jsx("button", { type: "button", "aria-label": label, title: label, "aria-pressed": isActiveDecorator(name)(snapshot), onMouseDown: (event) => event.preventDefault(), onClick: () => {
                    editor.send({ type: 'decorator.toggle', decorator: name });
                    editor.send({ type: 'focus' });
                }, children: _jsx(Icon, { size: 16, "aria-hidden": "true" }) }, name))), _jsx("button", { type: "button", "aria-label": "Link", title: "Link", "aria-pressed": isActiveAnnotation('link')(snapshot), onMouseDown: (event) => event.preventDefault(), onClick: () => {
                    selection.current = editor.getSnapshot().context.selection;
                    setLinkValue('');
                    setLinkError(false);
                    linkDialog.current?.showModal();
                }, children: _jsx(Link, { size: 16, "aria-hidden": "true" }) }), _jsx("dialog", { ref: linkDialog, className: "terra-docs-link-dialog", "aria-labelledby": `${linkId}-title`, children: _jsxs("form", { onSubmit: (event) => {
                        event.preventDefault();
                        const href = safeLink(linkValue);
                        if (!href) {
                            setLinkError(true);
                            return;
                        }
                        if (selection.current)
                            editor.send({ type: 'select', at: selection.current });
                        editor.send({ type: 'annotation.add', annotation: { name: 'link', value: { href } } });
                        linkDialog.current?.close();
                        editor.send({ type: 'focus' });
                    }, children: [_jsx("h2", { id: `${linkId}-title`, children: "Add link" }), _jsx("label", { htmlFor: `${linkId}-url`, children: "URL" }), _jsx("input", { id: `${linkId}-url`, autoFocus: true, required: true, value: linkValue, onChange: (event) => setLinkValue(event.currentTarget.value), placeholder: "https://example.com" }), linkError && _jsx("p", { role: "alert", children: "Enter a valid web, email, or relative URL." }), _jsxs("div", { children: [_jsx("button", { type: "button", onClick: () => {
                                        linkDialog.current?.close();
                                        editor.send({ type: 'focus' });
                                    }, children: "Cancel" }), _jsx("button", { type: "submit", children: "Add link" })] })] }) })] }));
}
//# sourceMappingURL=_Toolbar.js.map