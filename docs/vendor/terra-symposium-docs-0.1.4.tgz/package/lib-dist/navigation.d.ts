import type { JSX } from 'react';
export type DocsNavNode = {
    title: string;
    href?: string;
    children?: DocsNavNode[];
};
export declare function DocsNavigation({ nodes, currentPath, hue, }: {
    nodes: DocsNavNode[];
    currentPath: string;
    hue?: number | null;
}): JSX.Element;
//# sourceMappingURL=navigation.d.ts.map