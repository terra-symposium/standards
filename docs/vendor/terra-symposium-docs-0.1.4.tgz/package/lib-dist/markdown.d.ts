export declare function renderMarkdown(markdown: string): string;
//# sourceMappingURL=markdown.d.ts.map