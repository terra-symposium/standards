import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useMemo, useState } from 'react';
function firstLeaf(section) { return section.groups.flatMap(group => group.leaves)[0]?.href ?? '/'; }
function sectionForPath(sections, path) {
    return Math.max(0, sections.findIndex(section => section.groups.some(group => group.leaves.some(leaf => leaf.href === path))));
}
export function DocsWorkspaceNavigation({ sections, currentPath }) {
    const [sectionIndex, setSectionIndex] = useState(() => sectionForPath(sections, currentPath));
    const [query, setQuery] = useState('');
    useEffect(() => setSectionIndex(sectionForPath(sections, currentPath)), [sections, currentPath]);
    const section = sections[sectionIndex];
    const groups = useMemo(() => section?.groups.map(group => ({ ...group, leaves: group.leaves.filter(leaf => `${leaf.title} ${leaf.description ?? ''}`.toLowerCase().includes(query.toLowerCase())) })).filter(group => group.leaves.length) ?? [], [section, query]);
    return _jsxs("nav", { className: "terra-docs-workspace-nav", "aria-label": "Documentation", children: [_jsx("label", { className: "terra-docs-control-label", htmlFor: "terra-docs-section", children: "Section" }), _jsx("select", { id: "terra-docs-section", "aria-label": "Section", value: sectionIndex, onChange: event => { const index = Number(event.currentTarget.value); setSectionIndex(index); const href = sections[index] && firstLeaf(sections[index]); if (href)
                    window.location.assign(href); }, children: sections.map((entry, index) => _jsx("option", { value: index, children: entry.title }, `${entry.title}-${index}`)) }), _jsx("label", { className: "terra-docs-control-label", htmlFor: "terra-docs-search", children: "Search pages" }), _jsx("input", { id: "terra-docs-search", type: "search", value: query, onChange: event => setQuery(event.currentTarget.value), placeholder: "Search this section" }), _jsx("div", { className: "terra-docs-workspace-groups", children: groups.map((group, index) => _jsxs("div", { className: "terra-docs-workspace-group", children: [_jsx("h2", { children: group.title }), _jsx("ul", { children: group.leaves.map((leaf, leafIndex) => _jsx("li", { children: _jsx("a", { href: leaf.href, "aria-current": leaf.href === currentPath ? 'page' : undefined, children: leaf.title }) }, `${leaf.href}-${leafIndex}`)) })] }, `${group.title}-${index}`)) }), groups.length === 0 && _jsx("p", { className: "terra-docs-empty", children: "No pages found." })] });
}
export function DocsWorkspaceToolbar({ attachments = [], capabilities = {}, onEdit, onSave, onHistory }) {
    const [mode, setMode] = useState('view');
    useEffect(() => { const element = document.querySelector('.terra-docs-site'); if (element)
        element.dataset.docsMode = mode; return () => { if (element)
        delete element.dataset.docsMode; }; }, [mode]);
    return _jsxs("div", { className: "terra-docs-workspace-toolbar", role: "toolbar", "aria-label": "Document controls", children: [_jsx("label", { htmlFor: "terra-docs-mode", children: "Mode" }), _jsxs("select", { id: "terra-docs-mode", "aria-label": "Mode", value: mode, onChange: event => { const next = event.currentTarget.value; setMode(next); if (next === 'edit')
                    onEdit?.(); }, children: [_jsx("option", { value: "view", children: "View" }), _jsxs("option", { value: "attachments", children: ["Attachments", attachments.length ? ` (${attachments.length})` : ''] }), capabilities.edit && _jsx("option", { value: "edit", children: "Edit" })] }), mode === 'edit' && capabilities.save && _jsx("button", { type: "button", onClick: onSave, children: "Save" }), mode === 'edit' && capabilities.history && _jsx("button", { type: "button", onClick: onHistory, children: "History" })] });
}
export function DocsAttachmentsView({ attachments = [] }) {
    return _jsxs("section", { className: "terra-docs-attachments-view", "aria-label": "Attachments", children: [_jsx("h2", { children: "Attachments" }), attachments.length ? _jsx("ul", { children: attachments.map((attachment, index) => _jsxs("li", { children: [_jsx("a", { href: attachment.href, target: "_blank", rel: "noopener noreferrer", children: attachment.title }), attachment.type && _jsx("span", { children: attachment.type })] }, `${attachment.href}-${index}`)) }) : _jsx("p", { children: "No attachments found." })] });
}
//# sourceMappingURL=workspace.js.map